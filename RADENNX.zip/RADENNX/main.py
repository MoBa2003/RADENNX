from antlr4 import *
from gen.RADENNXLexer import RADENNXLexer
from code.Custom_RADENNX_Listener import RADENNXListener, CustomRADENNXListener
from gen.RADENNXParser import RADENNXParser
from ast_maker.radenn_nodes import *
from ast_maker.parse_result import ParseResult
from code.Code_gen import *

def main():
    # Load the input file
    input_file = 'tests/test5.rdnx'
    stream = FileStream(input_file, encoding='utf8')

    # Create the lexer
    lexer = RADENNXLexer(stream)

    token_stream = CommonTokenStream(lexer)
    parser = RADENNXParser(token_stream)

    parse_tree = parser.program()

    # Create a custom Code object
    listener = CustomRADENNXListener()

    # Walk the parse tree with the custom Code
    walker = ParseTreeWalker()
    walker.walk(listener, parse_tree)
    dot = draw_ast(listener.ast)
    dot.render("ast_output", format="png", view=True)

    ast = listener.ast
    result = generate_Code(ast)
    if result.error:
        print(result.error)



if __name__ == '__main__':
    main()
