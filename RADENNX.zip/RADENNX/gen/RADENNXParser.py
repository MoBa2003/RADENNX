# Generated from D:/5th_Semester_Concepts/Compiler_Design/Project/RADENNX/grammar/RADENNX.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,48,478,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        1,0,1,0,1,0,1,1,5,1,59,8,1,10,1,12,1,62,9,1,1,1,1,1,4,1,66,8,1,11,
        1,12,1,67,1,1,5,1,71,8,1,10,1,12,1,74,9,1,1,1,5,1,77,8,1,10,1,12,
        1,80,9,1,1,2,1,2,3,2,84,8,2,1,2,1,2,1,2,3,2,89,8,2,1,3,1,3,1,3,1,
        3,1,3,1,3,1,3,5,3,98,8,3,10,3,12,3,101,9,3,3,3,103,8,3,1,4,1,4,1,
        4,1,4,1,4,5,4,110,8,4,10,4,12,4,113,9,4,3,4,115,8,4,1,5,1,5,1,5,
        5,5,120,8,5,10,5,12,5,123,9,5,1,6,1,6,1,6,5,6,128,8,6,10,6,12,6,
        131,9,6,1,7,1,7,1,7,3,7,136,8,7,1,8,1,8,1,8,5,8,141,8,8,10,8,12,
        8,144,9,8,1,9,1,9,1,9,1,9,1,9,5,9,151,8,9,10,9,12,9,154,9,9,3,9,
        156,8,9,1,9,3,9,159,8,9,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,
        1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,1,10,
        3,10,182,8,10,1,11,1,11,1,11,1,11,5,11,188,8,11,10,11,12,11,191,
        9,11,3,11,193,8,11,1,11,1,11,1,12,1,12,1,12,1,12,5,12,201,8,12,10,
        12,12,12,204,9,12,3,12,206,8,12,1,12,1,12,1,13,1,13,1,13,1,13,5,
        13,214,8,13,10,13,12,13,217,9,13,1,13,1,13,1,14,1,14,1,14,1,14,1,
        14,1,14,1,14,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,16,1,16,1,16,1,
        16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,17,1,
        17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,18,1,
        18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,19,1,19,1,19,1,19,1,19,5,
        19,277,8,19,10,19,12,19,280,9,19,1,19,1,19,1,19,1,19,1,20,1,20,1,
        20,5,20,289,8,20,10,20,12,20,292,9,20,1,20,1,20,1,20,5,20,297,8,
        20,10,20,12,20,300,9,20,1,20,1,20,5,20,304,8,20,10,20,12,20,307,
        9,20,1,20,1,20,3,20,311,8,20,1,20,5,20,314,8,20,10,20,12,20,317,
        9,20,1,20,1,20,3,20,321,8,20,1,21,1,21,1,21,5,21,326,8,21,10,21,
        12,21,329,9,21,1,21,1,21,1,21,5,21,334,8,21,10,21,12,21,337,9,21,
        1,21,1,21,5,21,341,8,21,10,21,12,21,344,9,21,1,21,1,21,3,21,348,
        8,21,1,21,5,21,351,8,21,10,21,12,21,354,9,21,1,21,1,21,3,21,358,
        8,21,1,22,1,22,5,22,362,8,22,10,22,12,22,365,9,22,1,22,1,22,1,22,
        5,22,370,8,22,10,22,12,22,373,9,22,1,22,1,22,5,22,377,8,22,10,22,
        12,22,380,9,22,1,22,1,22,3,22,384,8,22,1,23,1,23,1,23,1,23,1,23,
        1,23,1,23,1,23,1,23,3,23,395,8,23,1,23,1,23,5,23,399,8,23,10,23,
        12,23,402,9,23,1,23,1,23,1,23,1,23,1,23,3,23,409,8,23,1,24,1,24,
        1,24,5,24,414,8,24,10,24,12,24,417,9,24,1,24,1,24,1,24,1,24,1,24,
        3,24,424,8,24,1,25,1,25,5,25,428,8,25,10,25,12,25,431,9,25,1,25,
        1,25,5,25,435,8,25,10,25,12,25,438,9,25,1,25,1,25,1,25,1,25,3,25,
        444,8,25,1,25,1,25,1,25,1,26,1,26,3,26,451,8,26,1,26,1,26,1,26,1,
        26,5,26,457,8,26,10,26,12,26,460,9,26,3,26,462,8,26,1,26,1,26,5,
        26,466,8,26,10,26,12,26,469,9,26,1,26,1,26,1,26,1,26,1,26,3,26,476,
        8,26,1,26,0,0,27,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,
        36,38,40,42,44,46,48,50,52,0,4,1,0,5,6,2,0,40,41,43,46,1,0,26,27,
        2,0,28,29,31,31,523,0,54,1,0,0,0,2,60,1,0,0,0,4,88,1,0,0,0,6,102,
        1,0,0,0,8,114,1,0,0,0,10,116,1,0,0,0,12,124,1,0,0,0,14,135,1,0,0,
        0,16,137,1,0,0,0,18,145,1,0,0,0,20,181,1,0,0,0,22,183,1,0,0,0,24,
        196,1,0,0,0,26,209,1,0,0,0,28,220,1,0,0,0,30,227,1,0,0,0,32,234,
        1,0,0,0,34,249,1,0,0,0,36,262,1,0,0,0,38,271,1,0,0,0,40,285,1,0,
        0,0,42,322,1,0,0,0,44,359,1,0,0,0,46,385,1,0,0,0,48,410,1,0,0,0,
        50,425,1,0,0,0,52,448,1,0,0,0,54,55,3,2,1,0,55,56,5,0,0,1,56,1,1,
        0,0,0,57,59,5,1,0,0,58,57,1,0,0,0,59,62,1,0,0,0,60,58,1,0,0,0,60,
        61,1,0,0,0,61,63,1,0,0,0,62,60,1,0,0,0,63,72,3,4,2,0,64,66,5,1,0,
        0,65,64,1,0,0,0,66,67,1,0,0,0,67,65,1,0,0,0,67,68,1,0,0,0,68,69,
        1,0,0,0,69,71,3,4,2,0,70,65,1,0,0,0,71,74,1,0,0,0,72,70,1,0,0,0,
        72,73,1,0,0,0,73,78,1,0,0,0,74,72,1,0,0,0,75,77,5,1,0,0,76,75,1,
        0,0,0,77,80,1,0,0,0,78,76,1,0,0,0,78,79,1,0,0,0,79,3,1,0,0,0,80,
        78,1,0,0,0,81,83,5,15,0,0,82,84,3,6,3,0,83,82,1,0,0,0,83,84,1,0,
        0,0,84,89,1,0,0,0,85,89,5,16,0,0,86,89,5,17,0,0,87,89,3,6,3,0,88,
        81,1,0,0,0,88,85,1,0,0,0,88,86,1,0,0,0,88,87,1,0,0,0,89,5,1,0,0,
        0,90,91,5,4,0,0,91,92,5,24,0,0,92,93,5,42,0,0,93,103,3,6,3,0,94,
        99,3,8,4,0,95,96,7,0,0,0,96,98,3,8,4,0,97,95,1,0,0,0,98,101,1,0,
        0,0,99,97,1,0,0,0,99,100,1,0,0,0,100,103,1,0,0,0,101,99,1,0,0,0,
        102,90,1,0,0,0,102,94,1,0,0,0,103,7,1,0,0,0,104,105,5,7,0,0,105,
        115,3,8,4,0,106,111,3,10,5,0,107,108,7,1,0,0,108,110,3,10,5,0,109,
        107,1,0,0,0,110,113,1,0,0,0,111,109,1,0,0,0,111,112,1,0,0,0,112,
        115,1,0,0,0,113,111,1,0,0,0,114,104,1,0,0,0,114,106,1,0,0,0,115,
        9,1,0,0,0,116,121,3,12,6,0,117,118,7,2,0,0,118,120,3,12,6,0,119,
        117,1,0,0,0,120,123,1,0,0,0,121,119,1,0,0,0,121,122,1,0,0,0,122,
        11,1,0,0,0,123,121,1,0,0,0,124,129,3,14,7,0,125,126,7,3,0,0,126,
        128,3,14,7,0,127,125,1,0,0,0,128,131,1,0,0,0,129,127,1,0,0,0,129,
        130,1,0,0,0,130,13,1,0,0,0,131,129,1,0,0,0,132,133,7,2,0,0,133,136,
        3,14,7,0,134,136,3,16,8,0,135,132,1,0,0,0,135,134,1,0,0,0,136,15,
        1,0,0,0,137,142,3,18,9,0,138,139,5,30,0,0,139,141,3,14,7,0,140,138,
        1,0,0,0,141,144,1,0,0,0,142,140,1,0,0,0,142,143,1,0,0,0,143,17,1,
        0,0,0,144,142,1,0,0,0,145,158,3,20,10,0,146,155,5,32,0,0,147,152,
        3,6,3,0,148,149,5,39,0,0,149,151,3,6,3,0,150,148,1,0,0,0,151,154,
        1,0,0,0,152,150,1,0,0,0,152,153,1,0,0,0,153,156,1,0,0,0,154,152,
        1,0,0,0,155,147,1,0,0,0,155,156,1,0,0,0,156,157,1,0,0,0,157,159,
        5,33,0,0,158,146,1,0,0,0,158,159,1,0,0,0,159,19,1,0,0,0,160,182,
        5,3,0,0,161,182,5,2,0,0,162,182,5,25,0,0,163,182,5,24,0,0,164,165,
        5,32,0,0,165,166,3,6,3,0,166,167,5,33,0,0,167,182,1,0,0,0,168,182,
        3,22,11,0,169,182,3,24,12,0,170,182,3,28,14,0,171,182,3,30,15,0,
        172,182,3,32,16,0,173,182,3,34,17,0,174,182,3,36,18,0,175,182,3,
        38,19,0,176,182,3,40,20,0,177,182,3,46,23,0,178,182,3,48,24,0,179,
        182,3,50,25,0,180,182,3,52,26,0,181,160,1,0,0,0,181,161,1,0,0,0,
        181,162,1,0,0,0,181,163,1,0,0,0,181,164,1,0,0,0,181,168,1,0,0,0,
        181,169,1,0,0,0,181,170,1,0,0,0,181,171,1,0,0,0,181,172,1,0,0,0,
        181,173,1,0,0,0,181,174,1,0,0,0,181,175,1,0,0,0,181,176,1,0,0,0,
        181,177,1,0,0,0,181,178,1,0,0,0,181,179,1,0,0,0,181,180,1,0,0,0,
        182,21,1,0,0,0,183,192,5,34,0,0,184,189,3,6,3,0,185,186,5,39,0,0,
        186,188,3,6,3,0,187,185,1,0,0,0,188,191,1,0,0,0,189,187,1,0,0,0,
        189,190,1,0,0,0,190,193,1,0,0,0,191,189,1,0,0,0,192,184,1,0,0,0,
        192,193,1,0,0,0,193,194,1,0,0,0,194,195,5,35,0,0,195,23,1,0,0,0,
        196,205,5,36,0,0,197,202,3,26,13,0,198,199,5,39,0,0,199,201,3,26,
        13,0,200,198,1,0,0,0,201,204,1,0,0,0,202,200,1,0,0,0,202,203,1,0,
        0,0,203,206,1,0,0,0,204,202,1,0,0,0,205,197,1,0,0,0,205,206,1,0,
        0,0,206,207,1,0,0,0,207,208,5,37,0,0,208,25,1,0,0,0,209,210,5,36,
        0,0,210,215,3,6,3,0,211,212,5,39,0,0,212,214,3,6,3,0,213,211,1,0,
        0,0,214,217,1,0,0,0,215,213,1,0,0,0,215,216,1,0,0,0,216,218,1,0,
        0,0,217,215,1,0,0,0,218,219,5,37,0,0,219,27,1,0,0,0,220,221,5,18,
        0,0,221,222,5,32,0,0,222,223,3,6,3,0,223,224,5,39,0,0,224,225,3,
        6,3,0,225,226,5,33,0,0,226,29,1,0,0,0,227,228,5,19,0,0,228,229,5,
        32,0,0,229,230,3,6,3,0,230,231,5,39,0,0,231,232,3,6,3,0,232,233,
        5,33,0,0,233,31,1,0,0,0,234,235,5,20,0,0,235,236,5,32,0,0,236,237,
        3,6,3,0,237,238,5,39,0,0,238,239,3,6,3,0,239,240,5,39,0,0,240,241,
        3,6,3,0,241,242,5,39,0,0,242,243,3,6,3,0,243,244,5,39,0,0,244,245,
        3,6,3,0,245,246,5,39,0,0,246,247,3,6,3,0,247,248,5,33,0,0,248,33,
        1,0,0,0,249,250,5,21,0,0,250,251,5,32,0,0,251,252,3,6,3,0,252,253,
        5,39,0,0,253,254,3,6,3,0,254,255,5,39,0,0,255,256,3,6,3,0,256,257,
        5,39,0,0,257,258,3,6,3,0,258,259,5,39,0,0,259,260,3,6,3,0,260,261,
        5,33,0,0,261,35,1,0,0,0,262,263,5,22,0,0,263,264,5,32,0,0,264,265,
        3,6,3,0,265,266,5,39,0,0,266,267,3,6,3,0,267,268,5,39,0,0,268,269,
        3,6,3,0,269,270,5,33,0,0,270,37,1,0,0,0,271,272,5,23,0,0,272,273,
        5,32,0,0,273,278,3,6,3,0,274,275,5,39,0,0,275,277,3,6,3,0,276,274,
        1,0,0,0,277,280,1,0,0,0,278,276,1,0,0,0,278,279,1,0,0,0,279,281,
        1,0,0,0,280,278,1,0,0,0,281,282,5,39,0,0,282,283,3,6,3,0,283,284,
        5,33,0,0,284,39,1,0,0,0,285,286,5,8,0,0,286,290,3,6,3,0,287,289,
        5,1,0,0,288,287,1,0,0,0,289,292,1,0,0,0,290,288,1,0,0,0,290,291,
        1,0,0,0,291,310,1,0,0,0,292,290,1,0,0,0,293,311,3,4,2,0,294,298,
        5,36,0,0,295,297,5,1,0,0,296,295,1,0,0,0,297,300,1,0,0,0,298,296,
        1,0,0,0,298,299,1,0,0,0,299,301,1,0,0,0,300,298,1,0,0,0,301,305,
        3,2,1,0,302,304,5,1,0,0,303,302,1,0,0,0,304,307,1,0,0,0,305,303,
        1,0,0,0,305,306,1,0,0,0,306,308,1,0,0,0,307,305,1,0,0,0,308,309,
        5,37,0,0,309,311,1,0,0,0,310,293,1,0,0,0,310,294,1,0,0,0,311,315,
        1,0,0,0,312,314,5,1,0,0,313,312,1,0,0,0,314,317,1,0,0,0,315,313,
        1,0,0,0,315,316,1,0,0,0,316,320,1,0,0,0,317,315,1,0,0,0,318,321,
        3,42,21,0,319,321,3,44,22,0,320,318,1,0,0,0,320,319,1,0,0,0,320,
        321,1,0,0,0,321,41,1,0,0,0,322,323,5,9,0,0,323,327,3,6,3,0,324,326,
        5,1,0,0,325,324,1,0,0,0,326,329,1,0,0,0,327,325,1,0,0,0,327,328,
        1,0,0,0,328,347,1,0,0,0,329,327,1,0,0,0,330,348,3,4,2,0,331,335,
        5,36,0,0,332,334,5,1,0,0,333,332,1,0,0,0,334,337,1,0,0,0,335,333,
        1,0,0,0,335,336,1,0,0,0,336,338,1,0,0,0,337,335,1,0,0,0,338,342,
        3,2,1,0,339,341,5,1,0,0,340,339,1,0,0,0,341,344,1,0,0,0,342,340,
        1,0,0,0,342,343,1,0,0,0,343,345,1,0,0,0,344,342,1,0,0,0,345,346,
        5,37,0,0,346,348,1,0,0,0,347,330,1,0,0,0,347,331,1,0,0,0,348,352,
        1,0,0,0,349,351,5,1,0,0,350,349,1,0,0,0,351,354,1,0,0,0,352,350,
        1,0,0,0,352,353,1,0,0,0,353,357,1,0,0,0,354,352,1,0,0,0,355,358,
        3,42,21,0,356,358,3,44,22,0,357,355,1,0,0,0,357,356,1,0,0,0,357,
        358,1,0,0,0,358,43,1,0,0,0,359,363,5,10,0,0,360,362,5,1,0,0,361,
        360,1,0,0,0,362,365,1,0,0,0,363,361,1,0,0,0,363,364,1,0,0,0,364,
        383,1,0,0,0,365,363,1,0,0,0,366,384,3,4,2,0,367,371,5,36,0,0,368,
        370,5,1,0,0,369,368,1,0,0,0,370,373,1,0,0,0,371,369,1,0,0,0,371,
        372,1,0,0,0,372,374,1,0,0,0,373,371,1,0,0,0,374,378,3,2,1,0,375,
        377,5,1,0,0,376,375,1,0,0,0,377,380,1,0,0,0,378,376,1,0,0,0,378,
        379,1,0,0,0,379,381,1,0,0,0,380,378,1,0,0,0,381,382,5,37,0,0,382,
        384,1,0,0,0,383,366,1,0,0,0,383,367,1,0,0,0,384,45,1,0,0,0,385,386,
        5,11,0,0,386,387,5,32,0,0,387,388,5,24,0,0,388,389,5,39,0,0,389,
        390,3,6,3,0,390,391,5,39,0,0,391,394,3,6,3,0,392,393,5,39,0,0,393,
        395,3,6,3,0,394,392,1,0,0,0,394,395,1,0,0,0,395,396,1,0,0,0,396,
        400,5,33,0,0,397,399,5,1,0,0,398,397,1,0,0,0,399,402,1,0,0,0,400,
        398,1,0,0,0,400,401,1,0,0,0,401,408,1,0,0,0,402,400,1,0,0,0,403,
        409,3,4,2,0,404,405,5,36,0,0,405,406,3,2,1,0,406,407,5,37,0,0,407,
        409,1,0,0,0,408,403,1,0,0,0,408,404,1,0,0,0,409,47,1,0,0,0,410,411,
        5,12,0,0,411,415,3,6,3,0,412,414,5,1,0,0,413,412,1,0,0,0,414,417,
        1,0,0,0,415,413,1,0,0,0,415,416,1,0,0,0,416,423,1,0,0,0,417,415,
        1,0,0,0,418,424,3,4,2,0,419,420,5,36,0,0,420,421,3,2,1,0,421,422,
        5,37,0,0,422,424,1,0,0,0,423,418,1,0,0,0,423,419,1,0,0,0,424,49,
        1,0,0,0,425,429,5,13,0,0,426,428,5,1,0,0,427,426,1,0,0,0,428,431,
        1,0,0,0,429,427,1,0,0,0,429,430,1,0,0,0,430,443,1,0,0,0,431,429,
        1,0,0,0,432,436,3,4,2,0,433,435,5,1,0,0,434,433,1,0,0,0,435,438,
        1,0,0,0,436,434,1,0,0,0,436,437,1,0,0,0,437,444,1,0,0,0,438,436,
        1,0,0,0,439,440,5,36,0,0,440,441,3,2,1,0,441,442,5,37,0,0,442,444,
        1,0,0,0,443,432,1,0,0,0,443,439,1,0,0,0,444,445,1,0,0,0,445,446,
        5,12,0,0,446,447,3,6,3,0,447,51,1,0,0,0,448,450,5,14,0,0,449,451,
        5,24,0,0,450,449,1,0,0,0,450,451,1,0,0,0,451,452,1,0,0,0,452,461,
        5,32,0,0,453,458,5,24,0,0,454,455,5,39,0,0,455,457,5,24,0,0,456,
        454,1,0,0,0,457,460,1,0,0,0,458,456,1,0,0,0,458,459,1,0,0,0,459,
        462,1,0,0,0,460,458,1,0,0,0,461,453,1,0,0,0,461,462,1,0,0,0,462,
        463,1,0,0,0,463,467,5,33,0,0,464,466,5,1,0,0,465,464,1,0,0,0,466,
        469,1,0,0,0,467,465,1,0,0,0,467,468,1,0,0,0,468,475,1,0,0,0,469,
        467,1,0,0,0,470,476,3,4,2,0,471,472,5,36,0,0,472,473,3,2,1,0,473,
        474,5,37,0,0,474,476,1,0,0,0,475,470,1,0,0,0,475,471,1,0,0,0,476,
        53,1,0,0,0,53,60,67,72,78,83,88,99,102,111,114,121,129,135,142,152,
        155,158,181,189,192,202,205,215,278,290,298,305,310,315,320,327,
        335,342,347,352,357,363,371,378,383,394,400,408,415,423,429,436,
        443,450,458,461,467,475
    ]

class RADENNXParser ( Parser ):

    grammarFileName = "RADENNX.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "'var'", "'and'", "'or'", "'not'", "'if'", "'elif'", 
                     "'else'", "'for'", "'while'", "'do'", "'function'", 
                     "'return'", "'continue'", "'break'", "'dataset'", "'optimizer'", 
                     "'inputLayer'", "'hiddenLayer'", "'outputLayer'", "'network'", 
                     "<INVALID>", "<INVALID>", "'+'", "'-'", "'*'", "'/'", 
                     "'^'", "'%'", "'('", "')'", "'['", "']'", "'{'", "'}'", 
                     "':'", "','", "'!='", "'=='", "'='", "'>='", "'>'", 
                     "'<='", "'<'" ]

    symbolicNames = [ "<INVALID>", "NEWLINE", "FLOAT", "INT", "VAR", "AND", 
                      "OR", "NOT", "IF", "ELIF", "ELSE", "FOR", "WHILE", 
                      "DO", "FUNCTION", "RETURN", "CONTINUE", "BREAK", "DATASET", 
                      "OPTIMIZER", "INPUTLAYER", "HIDDENLAYER", "OUTPUTLAYER", 
                      "NETWORK", "IDENTIFIER", "STRING", "PLUS", "MINUS", 
                      "MUL", "DIV", "POW", "MOD", "LPAREN", "RPAREN", "LSQUARE", 
                      "RSQUARE", "LROUND", "RROUND", "COLON", "COMMA", "NE", 
                      "EE", "EQ", "GTE", "GT", "LTE", "LT", "WS", "COMMENT" ]

    RULE_program = 0
    RULE_statements = 1
    RULE_statement = 2
    RULE_expr = 3
    RULE_comp_expr = 4
    RULE_arith_expr = 5
    RULE_term = 6
    RULE_factor = 7
    RULE_power = 8
    RULE_call = 9
    RULE_atom = 10
    RULE_list_expr = 11
    RULE_mat_expr = 12
    RULE_mat_row = 13
    RULE_dataset_expr = 14
    RULE_optimizer_expr = 15
    RULE_input_layer_expr = 16
    RULE_hidden_layer_expr = 17
    RULE_output_layer_expr = 18
    RULE_network_expr = 19
    RULE_if_expr = 20
    RULE_elif_expr = 21
    RULE_else_expr = 22
    RULE_for_expr = 23
    RULE_while_expr = 24
    RULE_do_while_expr = 25
    RULE_func_def = 26

    ruleNames =  [ "program", "statements", "statement", "expr", "comp_expr", 
                   "arith_expr", "term", "factor", "power", "call", "atom", 
                   "list_expr", "mat_expr", "mat_row", "dataset_expr", "optimizer_expr", 
                   "input_layer_expr", "hidden_layer_expr", "output_layer_expr", 
                   "network_expr", "if_expr", "elif_expr", "else_expr", 
                   "for_expr", "while_expr", "do_while_expr", "func_def" ]

    EOF = Token.EOF
    NEWLINE=1
    FLOAT=2
    INT=3
    VAR=4
    AND=5
    OR=6
    NOT=7
    IF=8
    ELIF=9
    ELSE=10
    FOR=11
    WHILE=12
    DO=13
    FUNCTION=14
    RETURN=15
    CONTINUE=16
    BREAK=17
    DATASET=18
    OPTIMIZER=19
    INPUTLAYER=20
    HIDDENLAYER=21
    OUTPUTLAYER=22
    NETWORK=23
    IDENTIFIER=24
    STRING=25
    PLUS=26
    MINUS=27
    MUL=28
    DIV=29
    POW=30
    MOD=31
    LPAREN=32
    RPAREN=33
    LSQUARE=34
    RSQUARE=35
    LROUND=36
    RROUND=37
    COLON=38
    COMMA=39
    NE=40
    EE=41
    EQ=42
    GTE=43
    GT=44
    LTE=45
    LT=46
    WS=47
    COMMENT=48

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statements(self):
            return self.getTypedRuleContext(RADENNXParser.StatementsContext,0)


        def EOF(self):
            return self.getToken(RADENNXParser.EOF, 0)

        def getRuleIndex(self):
            return RADENNXParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgram" ):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)




    def program(self):

        localctx = RADENNXParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 54
            self.statements()
            self.state = 55
            self.match(RADENNXParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.StatementContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.StatementContext,i)


        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.NEWLINE)
            else:
                return self.getToken(RADENNXParser.NEWLINE, i)

        def getRuleIndex(self):
            return RADENNXParser.RULE_statements

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatements" ):
                listener.enterStatements(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatements" ):
                listener.exitStatements(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatements" ):
                return visitor.visitStatements(self)
            else:
                return visitor.visitChildren(self)




    def statements(self):

        localctx = RADENNXParser.StatementsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_statements)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 60
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==1:
                self.state = 57
                self.match(RADENNXParser.NEWLINE)
                self.state = 62
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 63
            self.statement()
            self.state = 72
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,2,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 65 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while True:
                        self.state = 64
                        self.match(RADENNXParser.NEWLINE)
                        self.state = 67 
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        if not (_la==1):
                            break

                    self.state = 69
                    self.statement() 
                self.state = 74
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,2,self._ctx)

            self.state = 78
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,3,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 75
                    self.match(RADENNXParser.NEWLINE) 
                self.state = 80
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,3,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(RADENNXParser.RETURN, 0)

        def expr(self):
            return self.getTypedRuleContext(RADENNXParser.ExprContext,0)


        def CONTINUE(self):
            return self.getToken(RADENNXParser.CONTINUE, 0)

        def BREAK(self):
            return self.getToken(RADENNXParser.BREAK, 0)

        def getRuleIndex(self):
            return RADENNXParser.RULE_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatement" ):
                listener.enterStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatement" ):
                listener.exitStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatement" ):
                return visitor.visitStatement(self)
            else:
                return visitor.visitChildren(self)




    def statement(self):

        localctx = RADENNXParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_statement)
        try:
            self.state = 88
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [15]:
                self.enterOuterAlt(localctx, 1)
                self.state = 81
                self.match(RADENNXParser.RETURN)
                self.state = 83
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
                if la_ == 1:
                    self.state = 82
                    self.expr()


                pass
            elif token in [16]:
                self.enterOuterAlt(localctx, 2)
                self.state = 85
                self.match(RADENNXParser.CONTINUE)
                pass
            elif token in [17]:
                self.enterOuterAlt(localctx, 3)
                self.state = 86
                self.match(RADENNXParser.BREAK)
                pass
            elif token in [2, 3, 4, 7, 8, 11, 12, 13, 14, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 32, 34, 36]:
                self.enterOuterAlt(localctx, 4)
                self.state = 87
                self.expr()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VAR(self):
            return self.getToken(RADENNXParser.VAR, 0)

        def IDENTIFIER(self):
            return self.getToken(RADENNXParser.IDENTIFIER, 0)

        def EQ(self):
            return self.getToken(RADENNXParser.EQ, 0)

        def expr(self):
            return self.getTypedRuleContext(RADENNXParser.ExprContext,0)


        def comp_expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.Comp_exprContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.Comp_exprContext,i)


        def AND(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.AND)
            else:
                return self.getToken(RADENNXParser.AND, i)

        def OR(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.OR)
            else:
                return self.getToken(RADENNXParser.OR, i)

        def getRuleIndex(self):
            return RADENNXParser.RULE_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr" ):
                listener.enterExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr" ):
                listener.exitExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr" ):
                return visitor.visitExpr(self)
            else:
                return visitor.visitChildren(self)




    def expr(self):

        localctx = RADENNXParser.ExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_expr)
        self._la = 0 # Token type
        try:
            self.state = 102
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [4]:
                self.enterOuterAlt(localctx, 1)
                self.state = 90
                self.match(RADENNXParser.VAR)
                self.state = 91
                self.match(RADENNXParser.IDENTIFIER)
                self.state = 92
                self.match(RADENNXParser.EQ)
                self.state = 93
                self.expr()
                pass
            elif token in [2, 3, 7, 8, 11, 12, 13, 14, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 32, 34, 36]:
                self.enterOuterAlt(localctx, 2)
                self.state = 94
                self.comp_expr()
                self.state = 99
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,6,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 95
                        _la = self._input.LA(1)
                        if not(_la==5 or _la==6):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 96
                        self.comp_expr() 
                    self.state = 101
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,6,self._ctx)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Comp_exprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NOT(self):
            return self.getToken(RADENNXParser.NOT, 0)

        def comp_expr(self):
            return self.getTypedRuleContext(RADENNXParser.Comp_exprContext,0)


        def arith_expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.Arith_exprContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.Arith_exprContext,i)


        def EE(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.EE)
            else:
                return self.getToken(RADENNXParser.EE, i)

        def NE(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.NE)
            else:
                return self.getToken(RADENNXParser.NE, i)

        def LT(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.LT)
            else:
                return self.getToken(RADENNXParser.LT, i)

        def GT(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.GT)
            else:
                return self.getToken(RADENNXParser.GT, i)

        def LTE(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.LTE)
            else:
                return self.getToken(RADENNXParser.LTE, i)

        def GTE(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.GTE)
            else:
                return self.getToken(RADENNXParser.GTE, i)

        def getRuleIndex(self):
            return RADENNXParser.RULE_comp_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComp_expr" ):
                listener.enterComp_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComp_expr" ):
                listener.exitComp_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComp_expr" ):
                return visitor.visitComp_expr(self)
            else:
                return visitor.visitChildren(self)




    def comp_expr(self):

        localctx = RADENNXParser.Comp_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_comp_expr)
        self._la = 0 # Token type
        try:
            self.state = 114
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [7]:
                self.enterOuterAlt(localctx, 1)
                self.state = 104
                self.match(RADENNXParser.NOT)
                self.state = 105
                self.comp_expr()
                pass
            elif token in [2, 3, 8, 11, 12, 13, 14, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 32, 34, 36]:
                self.enterOuterAlt(localctx, 2)
                self.state = 106
                self.arith_expr()
                self.state = 111
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,8,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 107
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 135239930216448) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 108
                        self.arith_expr() 
                    self.state = 113
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,8,self._ctx)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Arith_exprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def term(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.TermContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.TermContext,i)


        def PLUS(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.PLUS)
            else:
                return self.getToken(RADENNXParser.PLUS, i)

        def MINUS(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.MINUS)
            else:
                return self.getToken(RADENNXParser.MINUS, i)

        def getRuleIndex(self):
            return RADENNXParser.RULE_arith_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArith_expr" ):
                listener.enterArith_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArith_expr" ):
                listener.exitArith_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArith_expr" ):
                return visitor.visitArith_expr(self)
            else:
                return visitor.visitChildren(self)




    def arith_expr(self):

        localctx = RADENNXParser.Arith_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_arith_expr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 116
            self.term()
            self.state = 121
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,10,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 117
                    _la = self._input.LA(1)
                    if not(_la==26 or _la==27):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 118
                    self.term() 
                self.state = 123
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,10,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TermContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def factor(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.FactorContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.FactorContext,i)


        def MUL(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.MUL)
            else:
                return self.getToken(RADENNXParser.MUL, i)

        def DIV(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.DIV)
            else:
                return self.getToken(RADENNXParser.DIV, i)

        def MOD(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.MOD)
            else:
                return self.getToken(RADENNXParser.MOD, i)

        def getRuleIndex(self):
            return RADENNXParser.RULE_term

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTerm" ):
                listener.enterTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTerm" ):
                listener.exitTerm(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTerm" ):
                return visitor.visitTerm(self)
            else:
                return visitor.visitChildren(self)




    def term(self):

        localctx = RADENNXParser.TermContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_term)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 124
            self.factor()
            self.state = 129
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,11,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 125
                    _la = self._input.LA(1)
                    if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 2952790016) != 0)):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 126
                    self.factor() 
                self.state = 131
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,11,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FactorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def factor(self):
            return self.getTypedRuleContext(RADENNXParser.FactorContext,0)


        def PLUS(self):
            return self.getToken(RADENNXParser.PLUS, 0)

        def MINUS(self):
            return self.getToken(RADENNXParser.MINUS, 0)

        def power(self):
            return self.getTypedRuleContext(RADENNXParser.PowerContext,0)


        def getRuleIndex(self):
            return RADENNXParser.RULE_factor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFactor" ):
                listener.enterFactor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFactor" ):
                listener.exitFactor(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFactor" ):
                return visitor.visitFactor(self)
            else:
                return visitor.visitChildren(self)




    def factor(self):

        localctx = RADENNXParser.FactorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_factor)
        self._la = 0 # Token type
        try:
            self.state = 135
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [26, 27]:
                self.enterOuterAlt(localctx, 1)
                self.state = 132
                _la = self._input.LA(1)
                if not(_la==26 or _la==27):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 133
                self.factor()
                pass
            elif token in [2, 3, 8, 11, 12, 13, 14, 18, 19, 20, 21, 22, 23, 24, 25, 32, 34, 36]:
                self.enterOuterAlt(localctx, 2)
                self.state = 134
                self.power()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PowerContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def call(self):
            return self.getTypedRuleContext(RADENNXParser.CallContext,0)


        def POW(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.POW)
            else:
                return self.getToken(RADENNXParser.POW, i)

        def factor(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.FactorContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.FactorContext,i)


        def getRuleIndex(self):
            return RADENNXParser.RULE_power

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPower" ):
                listener.enterPower(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPower" ):
                listener.exitPower(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPower" ):
                return visitor.visitPower(self)
            else:
                return visitor.visitChildren(self)




    def power(self):

        localctx = RADENNXParser.PowerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_power)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 137
            self.call()
            self.state = 142
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,13,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 138
                    self.match(RADENNXParser.POW)
                    self.state = 139
                    self.factor() 
                self.state = 144
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,13,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def atom(self):
            return self.getTypedRuleContext(RADENNXParser.AtomContext,0)


        def LPAREN(self):
            return self.getToken(RADENNXParser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(RADENNXParser.RPAREN, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.ExprContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.ExprContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.COMMA)
            else:
                return self.getToken(RADENNXParser.COMMA, i)

        def getRuleIndex(self):
            return RADENNXParser.RULE_call

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCall" ):
                listener.enterCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCall" ):
                listener.exitCall(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCall" ):
                return visitor.visitCall(self)
            else:
                return visitor.visitChildren(self)




    def call(self):

        localctx = RADENNXParser.CallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_call)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 145
            self.atom()
            self.state = 158
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,16,self._ctx)
            if la_ == 1:
                self.state = 146
                self.match(RADENNXParser.LPAREN)
                self.state = 155
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 90462517660) != 0):
                    self.state = 147
                    self.expr()
                    self.state = 152
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==39:
                        self.state = 148
                        self.match(RADENNXParser.COMMA)
                        self.state = 149
                        self.expr()
                        self.state = 154
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)



                self.state = 157
                self.match(RADENNXParser.RPAREN)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AtomContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(RADENNXParser.INT, 0)

        def FLOAT(self):
            return self.getToken(RADENNXParser.FLOAT, 0)

        def STRING(self):
            return self.getToken(RADENNXParser.STRING, 0)

        def IDENTIFIER(self):
            return self.getToken(RADENNXParser.IDENTIFIER, 0)

        def LPAREN(self):
            return self.getToken(RADENNXParser.LPAREN, 0)

        def expr(self):
            return self.getTypedRuleContext(RADENNXParser.ExprContext,0)


        def RPAREN(self):
            return self.getToken(RADENNXParser.RPAREN, 0)

        def list_expr(self):
            return self.getTypedRuleContext(RADENNXParser.List_exprContext,0)


        def mat_expr(self):
            return self.getTypedRuleContext(RADENNXParser.Mat_exprContext,0)


        def dataset_expr(self):
            return self.getTypedRuleContext(RADENNXParser.Dataset_exprContext,0)


        def optimizer_expr(self):
            return self.getTypedRuleContext(RADENNXParser.Optimizer_exprContext,0)


        def input_layer_expr(self):
            return self.getTypedRuleContext(RADENNXParser.Input_layer_exprContext,0)


        def hidden_layer_expr(self):
            return self.getTypedRuleContext(RADENNXParser.Hidden_layer_exprContext,0)


        def output_layer_expr(self):
            return self.getTypedRuleContext(RADENNXParser.Output_layer_exprContext,0)


        def network_expr(self):
            return self.getTypedRuleContext(RADENNXParser.Network_exprContext,0)


        def if_expr(self):
            return self.getTypedRuleContext(RADENNXParser.If_exprContext,0)


        def for_expr(self):
            return self.getTypedRuleContext(RADENNXParser.For_exprContext,0)


        def while_expr(self):
            return self.getTypedRuleContext(RADENNXParser.While_exprContext,0)


        def do_while_expr(self):
            return self.getTypedRuleContext(RADENNXParser.Do_while_exprContext,0)


        def func_def(self):
            return self.getTypedRuleContext(RADENNXParser.Func_defContext,0)


        def getRuleIndex(self):
            return RADENNXParser.RULE_atom

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtom" ):
                listener.enterAtom(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtom" ):
                listener.exitAtom(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAtom" ):
                return visitor.visitAtom(self)
            else:
                return visitor.visitChildren(self)




    def atom(self):

        localctx = RADENNXParser.AtomContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_atom)
        try:
            self.state = 181
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [3]:
                self.enterOuterAlt(localctx, 1)
                self.state = 160
                self.match(RADENNXParser.INT)
                pass
            elif token in [2]:
                self.enterOuterAlt(localctx, 2)
                self.state = 161
                self.match(RADENNXParser.FLOAT)
                pass
            elif token in [25]:
                self.enterOuterAlt(localctx, 3)
                self.state = 162
                self.match(RADENNXParser.STRING)
                pass
            elif token in [24]:
                self.enterOuterAlt(localctx, 4)
                self.state = 163
                self.match(RADENNXParser.IDENTIFIER)
                pass
            elif token in [32]:
                self.enterOuterAlt(localctx, 5)
                self.state = 164
                self.match(RADENNXParser.LPAREN)
                self.state = 165
                self.expr()
                self.state = 166
                self.match(RADENNXParser.RPAREN)
                pass
            elif token in [34]:
                self.enterOuterAlt(localctx, 6)
                self.state = 168
                self.list_expr()
                pass
            elif token in [36]:
                self.enterOuterAlt(localctx, 7)
                self.state = 169
                self.mat_expr()
                pass
            elif token in [18]:
                self.enterOuterAlt(localctx, 8)
                self.state = 170
                self.dataset_expr()
                pass
            elif token in [19]:
                self.enterOuterAlt(localctx, 9)
                self.state = 171
                self.optimizer_expr()
                pass
            elif token in [20]:
                self.enterOuterAlt(localctx, 10)
                self.state = 172
                self.input_layer_expr()
                pass
            elif token in [21]:
                self.enterOuterAlt(localctx, 11)
                self.state = 173
                self.hidden_layer_expr()
                pass
            elif token in [22]:
                self.enterOuterAlt(localctx, 12)
                self.state = 174
                self.output_layer_expr()
                pass
            elif token in [23]:
                self.enterOuterAlt(localctx, 13)
                self.state = 175
                self.network_expr()
                pass
            elif token in [8]:
                self.enterOuterAlt(localctx, 14)
                self.state = 176
                self.if_expr()
                pass
            elif token in [11]:
                self.enterOuterAlt(localctx, 15)
                self.state = 177
                self.for_expr()
                pass
            elif token in [12]:
                self.enterOuterAlt(localctx, 16)
                self.state = 178
                self.while_expr()
                pass
            elif token in [13]:
                self.enterOuterAlt(localctx, 17)
                self.state = 179
                self.do_while_expr()
                pass
            elif token in [14]:
                self.enterOuterAlt(localctx, 18)
                self.state = 180
                self.func_def()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class List_exprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LSQUARE(self):
            return self.getToken(RADENNXParser.LSQUARE, 0)

        def RSQUARE(self):
            return self.getToken(RADENNXParser.RSQUARE, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.ExprContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.ExprContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.COMMA)
            else:
                return self.getToken(RADENNXParser.COMMA, i)

        def getRuleIndex(self):
            return RADENNXParser.RULE_list_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterList_expr" ):
                listener.enterList_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitList_expr" ):
                listener.exitList_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitList_expr" ):
                return visitor.visitList_expr(self)
            else:
                return visitor.visitChildren(self)




    def list_expr(self):

        localctx = RADENNXParser.List_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_list_expr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 183
            self.match(RADENNXParser.LSQUARE)
            self.state = 192
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 90462517660) != 0):
                self.state = 184
                self.expr()
                self.state = 189
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==39:
                    self.state = 185
                    self.match(RADENNXParser.COMMA)
                    self.state = 186
                    self.expr()
                    self.state = 191
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 194
            self.match(RADENNXParser.RSQUARE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Mat_exprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LROUND(self):
            return self.getToken(RADENNXParser.LROUND, 0)

        def RROUND(self):
            return self.getToken(RADENNXParser.RROUND, 0)

        def mat_row(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.Mat_rowContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.Mat_rowContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.COMMA)
            else:
                return self.getToken(RADENNXParser.COMMA, i)

        def getRuleIndex(self):
            return RADENNXParser.RULE_mat_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMat_expr" ):
                listener.enterMat_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMat_expr" ):
                listener.exitMat_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMat_expr" ):
                return visitor.visitMat_expr(self)
            else:
                return visitor.visitChildren(self)




    def mat_expr(self):

        localctx = RADENNXParser.Mat_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_mat_expr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 196
            self.match(RADENNXParser.LROUND)
            self.state = 205
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==36:
                self.state = 197
                self.mat_row()
                self.state = 202
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==39:
                    self.state = 198
                    self.match(RADENNXParser.COMMA)
                    self.state = 199
                    self.mat_row()
                    self.state = 204
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 207
            self.match(RADENNXParser.RROUND)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Mat_rowContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LROUND(self):
            return self.getToken(RADENNXParser.LROUND, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.ExprContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.ExprContext,i)


        def RROUND(self):
            return self.getToken(RADENNXParser.RROUND, 0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.COMMA)
            else:
                return self.getToken(RADENNXParser.COMMA, i)

        def getRuleIndex(self):
            return RADENNXParser.RULE_mat_row

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMat_row" ):
                listener.enterMat_row(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMat_row" ):
                listener.exitMat_row(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMat_row" ):
                return visitor.visitMat_row(self)
            else:
                return visitor.visitChildren(self)




    def mat_row(self):

        localctx = RADENNXParser.Mat_rowContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_mat_row)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 209
            self.match(RADENNXParser.LROUND)
            self.state = 210
            self.expr()
            self.state = 215
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==39:
                self.state = 211
                self.match(RADENNXParser.COMMA)
                self.state = 212
                self.expr()
                self.state = 217
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 218
            self.match(RADENNXParser.RROUND)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dataset_exprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DATASET(self):
            return self.getToken(RADENNXParser.DATASET, 0)

        def LPAREN(self):
            return self.getToken(RADENNXParser.LPAREN, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.ExprContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.ExprContext,i)


        def COMMA(self):
            return self.getToken(RADENNXParser.COMMA, 0)

        def RPAREN(self):
            return self.getToken(RADENNXParser.RPAREN, 0)

        def getRuleIndex(self):
            return RADENNXParser.RULE_dataset_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDataset_expr" ):
                listener.enterDataset_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDataset_expr" ):
                listener.exitDataset_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDataset_expr" ):
                return visitor.visitDataset_expr(self)
            else:
                return visitor.visitChildren(self)




    def dataset_expr(self):

        localctx = RADENNXParser.Dataset_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_dataset_expr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 220
            self.match(RADENNXParser.DATASET)
            self.state = 221
            self.match(RADENNXParser.LPAREN)
            self.state = 222
            self.expr()
            self.state = 223
            self.match(RADENNXParser.COMMA)
            self.state = 224
            self.expr()
            self.state = 225
            self.match(RADENNXParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Optimizer_exprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OPTIMIZER(self):
            return self.getToken(RADENNXParser.OPTIMIZER, 0)

        def LPAREN(self):
            return self.getToken(RADENNXParser.LPAREN, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.ExprContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.ExprContext,i)


        def COMMA(self):
            return self.getToken(RADENNXParser.COMMA, 0)

        def RPAREN(self):
            return self.getToken(RADENNXParser.RPAREN, 0)

        def getRuleIndex(self):
            return RADENNXParser.RULE_optimizer_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOptimizer_expr" ):
                listener.enterOptimizer_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOptimizer_expr" ):
                listener.exitOptimizer_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOptimizer_expr" ):
                return visitor.visitOptimizer_expr(self)
            else:
                return visitor.visitChildren(self)




    def optimizer_expr(self):

        localctx = RADENNXParser.Optimizer_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_optimizer_expr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 227
            self.match(RADENNXParser.OPTIMIZER)
            self.state = 228
            self.match(RADENNXParser.LPAREN)
            self.state = 229
            self.expr()
            self.state = 230
            self.match(RADENNXParser.COMMA)
            self.state = 231
            self.expr()
            self.state = 232
            self.match(RADENNXParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Input_layer_exprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INPUTLAYER(self):
            return self.getToken(RADENNXParser.INPUTLAYER, 0)

        def LPAREN(self):
            return self.getToken(RADENNXParser.LPAREN, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.ExprContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.ExprContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.COMMA)
            else:
                return self.getToken(RADENNXParser.COMMA, i)

        def RPAREN(self):
            return self.getToken(RADENNXParser.RPAREN, 0)

        def getRuleIndex(self):
            return RADENNXParser.RULE_input_layer_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInput_layer_expr" ):
                listener.enterInput_layer_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInput_layer_expr" ):
                listener.exitInput_layer_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInput_layer_expr" ):
                return visitor.visitInput_layer_expr(self)
            else:
                return visitor.visitChildren(self)




    def input_layer_expr(self):

        localctx = RADENNXParser.Input_layer_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_input_layer_expr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 234
            self.match(RADENNXParser.INPUTLAYER)
            self.state = 235
            self.match(RADENNXParser.LPAREN)
            self.state = 236
            self.expr()
            self.state = 237
            self.match(RADENNXParser.COMMA)
            self.state = 238
            self.expr()
            self.state = 239
            self.match(RADENNXParser.COMMA)
            self.state = 240
            self.expr()
            self.state = 241
            self.match(RADENNXParser.COMMA)
            self.state = 242
            self.expr()
            self.state = 243
            self.match(RADENNXParser.COMMA)
            self.state = 244
            self.expr()
            self.state = 245
            self.match(RADENNXParser.COMMA)
            self.state = 246
            self.expr()
            self.state = 247
            self.match(RADENNXParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Hidden_layer_exprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def HIDDENLAYER(self):
            return self.getToken(RADENNXParser.HIDDENLAYER, 0)

        def LPAREN(self):
            return self.getToken(RADENNXParser.LPAREN, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.ExprContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.ExprContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.COMMA)
            else:
                return self.getToken(RADENNXParser.COMMA, i)

        def RPAREN(self):
            return self.getToken(RADENNXParser.RPAREN, 0)

        def getRuleIndex(self):
            return RADENNXParser.RULE_hidden_layer_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHidden_layer_expr" ):
                listener.enterHidden_layer_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHidden_layer_expr" ):
                listener.exitHidden_layer_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitHidden_layer_expr" ):
                return visitor.visitHidden_layer_expr(self)
            else:
                return visitor.visitChildren(self)




    def hidden_layer_expr(self):

        localctx = RADENNXParser.Hidden_layer_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_hidden_layer_expr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 249
            self.match(RADENNXParser.HIDDENLAYER)
            self.state = 250
            self.match(RADENNXParser.LPAREN)
            self.state = 251
            self.expr()
            self.state = 252
            self.match(RADENNXParser.COMMA)
            self.state = 253
            self.expr()
            self.state = 254
            self.match(RADENNXParser.COMMA)
            self.state = 255
            self.expr()
            self.state = 256
            self.match(RADENNXParser.COMMA)
            self.state = 257
            self.expr()
            self.state = 258
            self.match(RADENNXParser.COMMA)
            self.state = 259
            self.expr()
            self.state = 260
            self.match(RADENNXParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Output_layer_exprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OUTPUTLAYER(self):
            return self.getToken(RADENNXParser.OUTPUTLAYER, 0)

        def LPAREN(self):
            return self.getToken(RADENNXParser.LPAREN, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.ExprContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.ExprContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.COMMA)
            else:
                return self.getToken(RADENNXParser.COMMA, i)

        def RPAREN(self):
            return self.getToken(RADENNXParser.RPAREN, 0)

        def getRuleIndex(self):
            return RADENNXParser.RULE_output_layer_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOutput_layer_expr" ):
                listener.enterOutput_layer_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOutput_layer_expr" ):
                listener.exitOutput_layer_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOutput_layer_expr" ):
                return visitor.visitOutput_layer_expr(self)
            else:
                return visitor.visitChildren(self)




    def output_layer_expr(self):

        localctx = RADENNXParser.Output_layer_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_output_layer_expr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 262
            self.match(RADENNXParser.OUTPUTLAYER)
            self.state = 263
            self.match(RADENNXParser.LPAREN)
            self.state = 264
            self.expr()
            self.state = 265
            self.match(RADENNXParser.COMMA)
            self.state = 266
            self.expr()
            self.state = 267
            self.match(RADENNXParser.COMMA)
            self.state = 268
            self.expr()
            self.state = 269
            self.match(RADENNXParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Network_exprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NETWORK(self):
            return self.getToken(RADENNXParser.NETWORK, 0)

        def LPAREN(self):
            return self.getToken(RADENNXParser.LPAREN, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.ExprContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.ExprContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.COMMA)
            else:
                return self.getToken(RADENNXParser.COMMA, i)

        def RPAREN(self):
            return self.getToken(RADENNXParser.RPAREN, 0)

        def getRuleIndex(self):
            return RADENNXParser.RULE_network_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNetwork_expr" ):
                listener.enterNetwork_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNetwork_expr" ):
                listener.exitNetwork_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNetwork_expr" ):
                return visitor.visitNetwork_expr(self)
            else:
                return visitor.visitChildren(self)




    def network_expr(self):

        localctx = RADENNXParser.Network_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_network_expr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 271
            self.match(RADENNXParser.NETWORK)
            self.state = 272
            self.match(RADENNXParser.LPAREN)
            self.state = 273
            self.expr()
            self.state = 278
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,23,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 274
                    self.match(RADENNXParser.COMMA)
                    self.state = 275
                    self.expr() 
                self.state = 280
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,23,self._ctx)

            self.state = 281
            self.match(RADENNXParser.COMMA)
            self.state = 282
            self.expr()
            self.state = 283
            self.match(RADENNXParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class If_exprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(RADENNXParser.IF, 0)

        def expr(self):
            return self.getTypedRuleContext(RADENNXParser.ExprContext,0)


        def statement(self):
            return self.getTypedRuleContext(RADENNXParser.StatementContext,0)


        def LROUND(self):
            return self.getToken(RADENNXParser.LROUND, 0)

        def statements(self):
            return self.getTypedRuleContext(RADENNXParser.StatementsContext,0)


        def RROUND(self):
            return self.getToken(RADENNXParser.RROUND, 0)

        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.NEWLINE)
            else:
                return self.getToken(RADENNXParser.NEWLINE, i)

        def elif_expr(self):
            return self.getTypedRuleContext(RADENNXParser.Elif_exprContext,0)


        def else_expr(self):
            return self.getTypedRuleContext(RADENNXParser.Else_exprContext,0)


        def getRuleIndex(self):
            return RADENNXParser.RULE_if_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIf_expr" ):
                listener.enterIf_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIf_expr" ):
                listener.exitIf_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIf_expr" ):
                return visitor.visitIf_expr(self)
            else:
                return visitor.visitChildren(self)




    def if_expr(self):

        localctx = RADENNXParser.If_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_if_expr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 285
            self.match(RADENNXParser.IF)
            self.state = 286
            self.expr()

            self.state = 290
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==1:
                self.state = 287
                self.match(RADENNXParser.NEWLINE)
                self.state = 292
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 310
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,27,self._ctx)
            if la_ == 1:
                self.state = 293
                self.statement()
                pass

            elif la_ == 2:
                self.state = 294
                self.match(RADENNXParser.LROUND)
                self.state = 298
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,25,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 295
                        self.match(RADENNXParser.NEWLINE) 
                    self.state = 300
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,25,self._ctx)

                self.state = 301
                self.statements()
                self.state = 305
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==1:
                    self.state = 302
                    self.match(RADENNXParser.NEWLINE)
                    self.state = 307
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 308
                self.match(RADENNXParser.RROUND)
                pass


            self.state = 315
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,28,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 312
                    self.match(RADENNXParser.NEWLINE) 
                self.state = 317
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,28,self._ctx)

            self.state = 320
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,29,self._ctx)
            if la_ == 1:
                self.state = 318
                self.elif_expr()

            elif la_ == 2:
                self.state = 319
                self.else_expr()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Elif_exprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ELIF(self):
            return self.getToken(RADENNXParser.ELIF, 0)

        def expr(self):
            return self.getTypedRuleContext(RADENNXParser.ExprContext,0)


        def statement(self):
            return self.getTypedRuleContext(RADENNXParser.StatementContext,0)


        def LROUND(self):
            return self.getToken(RADENNXParser.LROUND, 0)

        def statements(self):
            return self.getTypedRuleContext(RADENNXParser.StatementsContext,0)


        def RROUND(self):
            return self.getToken(RADENNXParser.RROUND, 0)

        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.NEWLINE)
            else:
                return self.getToken(RADENNXParser.NEWLINE, i)

        def elif_expr(self):
            return self.getTypedRuleContext(RADENNXParser.Elif_exprContext,0)


        def else_expr(self):
            return self.getTypedRuleContext(RADENNXParser.Else_exprContext,0)


        def getRuleIndex(self):
            return RADENNXParser.RULE_elif_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterElif_expr" ):
                listener.enterElif_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitElif_expr" ):
                listener.exitElif_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitElif_expr" ):
                return visitor.visitElif_expr(self)
            else:
                return visitor.visitChildren(self)




    def elif_expr(self):

        localctx = RADENNXParser.Elif_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_elif_expr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 322
            self.match(RADENNXParser.ELIF)
            self.state = 323
            self.expr()

            self.state = 327
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==1:
                self.state = 324
                self.match(RADENNXParser.NEWLINE)
                self.state = 329
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 347
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,33,self._ctx)
            if la_ == 1:
                self.state = 330
                self.statement()
                pass

            elif la_ == 2:
                self.state = 331
                self.match(RADENNXParser.LROUND)
                self.state = 335
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,31,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 332
                        self.match(RADENNXParser.NEWLINE) 
                    self.state = 337
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,31,self._ctx)

                self.state = 338
                self.statements()
                self.state = 342
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==1:
                    self.state = 339
                    self.match(RADENNXParser.NEWLINE)
                    self.state = 344
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 345
                self.match(RADENNXParser.RROUND)
                pass


            self.state = 352
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,34,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 349
                    self.match(RADENNXParser.NEWLINE) 
                self.state = 354
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,34,self._ctx)

            self.state = 357
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,35,self._ctx)
            if la_ == 1:
                self.state = 355
                self.elif_expr()

            elif la_ == 2:
                self.state = 356
                self.else_expr()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Else_exprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ELSE(self):
            return self.getToken(RADENNXParser.ELSE, 0)

        def statement(self):
            return self.getTypedRuleContext(RADENNXParser.StatementContext,0)


        def LROUND(self):
            return self.getToken(RADENNXParser.LROUND, 0)

        def statements(self):
            return self.getTypedRuleContext(RADENNXParser.StatementsContext,0)


        def RROUND(self):
            return self.getToken(RADENNXParser.RROUND, 0)

        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.NEWLINE)
            else:
                return self.getToken(RADENNXParser.NEWLINE, i)

        def getRuleIndex(self):
            return RADENNXParser.RULE_else_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterElse_expr" ):
                listener.enterElse_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitElse_expr" ):
                listener.exitElse_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitElse_expr" ):
                return visitor.visitElse_expr(self)
            else:
                return visitor.visitChildren(self)




    def else_expr(self):

        localctx = RADENNXParser.Else_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_else_expr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 359
            self.match(RADENNXParser.ELSE)

            self.state = 363
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==1:
                self.state = 360
                self.match(RADENNXParser.NEWLINE)
                self.state = 365
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 383
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,39,self._ctx)
            if la_ == 1:
                self.state = 366
                self.statement()
                pass

            elif la_ == 2:
                self.state = 367
                self.match(RADENNXParser.LROUND)
                self.state = 371
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,37,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 368
                        self.match(RADENNXParser.NEWLINE) 
                    self.state = 373
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,37,self._ctx)

                self.state = 374
                self.statements()
                self.state = 378
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==1:
                    self.state = 375
                    self.match(RADENNXParser.NEWLINE)
                    self.state = 380
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 381
                self.match(RADENNXParser.RROUND)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class For_exprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FOR(self):
            return self.getToken(RADENNXParser.FOR, 0)

        def LPAREN(self):
            return self.getToken(RADENNXParser.LPAREN, 0)

        def IDENTIFIER(self):
            return self.getToken(RADENNXParser.IDENTIFIER, 0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.COMMA)
            else:
                return self.getToken(RADENNXParser.COMMA, i)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(RADENNXParser.ExprContext)
            else:
                return self.getTypedRuleContext(RADENNXParser.ExprContext,i)


        def RPAREN(self):
            return self.getToken(RADENNXParser.RPAREN, 0)

        def statement(self):
            return self.getTypedRuleContext(RADENNXParser.StatementContext,0)


        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.NEWLINE)
            else:
                return self.getToken(RADENNXParser.NEWLINE, i)

        def LROUND(self):
            return self.getToken(RADENNXParser.LROUND, 0)

        def statements(self):
            return self.getTypedRuleContext(RADENNXParser.StatementsContext,0)


        def RROUND(self):
            return self.getToken(RADENNXParser.RROUND, 0)

        def getRuleIndex(self):
            return RADENNXParser.RULE_for_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFor_expr" ):
                listener.enterFor_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFor_expr" ):
                listener.exitFor_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFor_expr" ):
                return visitor.visitFor_expr(self)
            else:
                return visitor.visitChildren(self)




    def for_expr(self):

        localctx = RADENNXParser.For_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_for_expr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 385
            self.match(RADENNXParser.FOR)
            self.state = 386
            self.match(RADENNXParser.LPAREN)
            self.state = 387
            self.match(RADENNXParser.IDENTIFIER)
            self.state = 388
            self.match(RADENNXParser.COMMA)
            self.state = 389
            self.expr()
            self.state = 390
            self.match(RADENNXParser.COMMA)
            self.state = 391
            self.expr()
            self.state = 394
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==39:
                self.state = 392
                self.match(RADENNXParser.COMMA)
                self.state = 393
                self.expr()


            self.state = 396
            self.match(RADENNXParser.RPAREN)

            self.state = 400
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==1:
                self.state = 397
                self.match(RADENNXParser.NEWLINE)
                self.state = 402
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 408
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,42,self._ctx)
            if la_ == 1:
                self.state = 403
                self.statement()
                pass

            elif la_ == 2:
                self.state = 404
                self.match(RADENNXParser.LROUND)
                self.state = 405
                self.statements()
                self.state = 406
                self.match(RADENNXParser.RROUND)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class While_exprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WHILE(self):
            return self.getToken(RADENNXParser.WHILE, 0)

        def expr(self):
            return self.getTypedRuleContext(RADENNXParser.ExprContext,0)


        def statement(self):
            return self.getTypedRuleContext(RADENNXParser.StatementContext,0)


        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.NEWLINE)
            else:
                return self.getToken(RADENNXParser.NEWLINE, i)

        def LROUND(self):
            return self.getToken(RADENNXParser.LROUND, 0)

        def statements(self):
            return self.getTypedRuleContext(RADENNXParser.StatementsContext,0)


        def RROUND(self):
            return self.getToken(RADENNXParser.RROUND, 0)

        def getRuleIndex(self):
            return RADENNXParser.RULE_while_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhile_expr" ):
                listener.enterWhile_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhile_expr" ):
                listener.exitWhile_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhile_expr" ):
                return visitor.visitWhile_expr(self)
            else:
                return visitor.visitChildren(self)




    def while_expr(self):

        localctx = RADENNXParser.While_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_while_expr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 410
            self.match(RADENNXParser.WHILE)
            self.state = 411
            self.expr()

            self.state = 415
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==1:
                self.state = 412
                self.match(RADENNXParser.NEWLINE)
                self.state = 417
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 423
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,44,self._ctx)
            if la_ == 1:
                self.state = 418
                self.statement()
                pass

            elif la_ == 2:
                self.state = 419
                self.match(RADENNXParser.LROUND)
                self.state = 420
                self.statements()
                self.state = 421
                self.match(RADENNXParser.RROUND)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Do_while_exprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DO(self):
            return self.getToken(RADENNXParser.DO, 0)

        def WHILE(self):
            return self.getToken(RADENNXParser.WHILE, 0)

        def expr(self):
            return self.getTypedRuleContext(RADENNXParser.ExprContext,0)


        def statement(self):
            return self.getTypedRuleContext(RADENNXParser.StatementContext,0)


        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.NEWLINE)
            else:
                return self.getToken(RADENNXParser.NEWLINE, i)

        def LROUND(self):
            return self.getToken(RADENNXParser.LROUND, 0)

        def statements(self):
            return self.getTypedRuleContext(RADENNXParser.StatementsContext,0)


        def RROUND(self):
            return self.getToken(RADENNXParser.RROUND, 0)

        def getRuleIndex(self):
            return RADENNXParser.RULE_do_while_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDo_while_expr" ):
                listener.enterDo_while_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDo_while_expr" ):
                listener.exitDo_while_expr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDo_while_expr" ):
                return visitor.visitDo_while_expr(self)
            else:
                return visitor.visitChildren(self)




    def do_while_expr(self):

        localctx = RADENNXParser.Do_while_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_do_while_expr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 425
            self.match(RADENNXParser.DO)

            self.state = 429
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==1:
                self.state = 426
                self.match(RADENNXParser.NEWLINE)
                self.state = 431
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 443
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,47,self._ctx)
            if la_ == 1:
                self.state = 432
                self.statement()
                self.state = 436
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==1:
                    self.state = 433
                    self.match(RADENNXParser.NEWLINE)
                    self.state = 438
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass

            elif la_ == 2:
                self.state = 439
                self.match(RADENNXParser.LROUND)
                self.state = 440
                self.statements()
                self.state = 441
                self.match(RADENNXParser.RROUND)
                pass


            self.state = 445
            self.match(RADENNXParser.WHILE)
            self.state = 446
            self.expr()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Func_defContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FUNCTION(self):
            return self.getToken(RADENNXParser.FUNCTION, 0)

        def LPAREN(self):
            return self.getToken(RADENNXParser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(RADENNXParser.RPAREN, 0)

        def IDENTIFIER(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.IDENTIFIER)
            else:
                return self.getToken(RADENNXParser.IDENTIFIER, i)

        def statement(self):
            return self.getTypedRuleContext(RADENNXParser.StatementContext,0)


        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.NEWLINE)
            else:
                return self.getToken(RADENNXParser.NEWLINE, i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(RADENNXParser.COMMA)
            else:
                return self.getToken(RADENNXParser.COMMA, i)

        def LROUND(self):
            return self.getToken(RADENNXParser.LROUND, 0)

        def statements(self):
            return self.getTypedRuleContext(RADENNXParser.StatementsContext,0)


        def RROUND(self):
            return self.getToken(RADENNXParser.RROUND, 0)

        def getRuleIndex(self):
            return RADENNXParser.RULE_func_def

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunc_def" ):
                listener.enterFunc_def(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunc_def" ):
                listener.exitFunc_def(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunc_def" ):
                return visitor.visitFunc_def(self)
            else:
                return visitor.visitChildren(self)




    def func_def(self):

        localctx = RADENNXParser.Func_defContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_func_def)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 448
            self.match(RADENNXParser.FUNCTION)
            self.state = 450
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 449
                self.match(RADENNXParser.IDENTIFIER)


            self.state = 452
            self.match(RADENNXParser.LPAREN)
            self.state = 461
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 453
                self.match(RADENNXParser.IDENTIFIER)
                self.state = 458
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==39:
                    self.state = 454
                    self.match(RADENNXParser.COMMA)
                    self.state = 455
                    self.match(RADENNXParser.IDENTIFIER)
                    self.state = 460
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 463
            self.match(RADENNXParser.RPAREN)

            self.state = 467
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==1:
                self.state = 464
                self.match(RADENNXParser.NEWLINE)
                self.state = 469
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 475
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,52,self._ctx)
            if la_ == 1:
                self.state = 470
                self.statement()
                pass

            elif la_ == 2:
                self.state = 471
                self.match(RADENNXParser.LROUND)
                self.state = 472
                self.statements()
                self.state = 473
                self.match(RADENNXParser.RROUND)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





