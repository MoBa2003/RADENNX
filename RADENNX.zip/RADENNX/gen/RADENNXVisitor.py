# Generated from D:/5th_Semester_Concepts/Compiler_Design/Project/RADENNX/grammar/RADENNX.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .RADENNXParser import RADENNXParser
else:
    from RADENNXParser import RADENNXParser

# This class defines a complete generic visitor for a parse tree produced by RADENNXParser.

class RADENNXVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by RADENNXParser#program.
    def visitProgram(self, ctx:RADENNXParser.ProgramContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#statements.
    def visitStatements(self, ctx:RADENNXParser.StatementsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#statement.
    def visitStatement(self, ctx:RADENNXParser.StatementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#expr.
    def visitExpr(self, ctx:RADENNXParser.ExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#comp_expr.
    def visitComp_expr(self, ctx:RADENNXParser.Comp_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#arith_expr.
    def visitArith_expr(self, ctx:RADENNXParser.Arith_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#term.
    def visitTerm(self, ctx:RADENNXParser.TermContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#factor.
    def visitFactor(self, ctx:RADENNXParser.FactorContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#power.
    def visitPower(self, ctx:RADENNXParser.PowerContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#call.
    def visitCall(self, ctx:RADENNXParser.CallContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#atom.
    def visitAtom(self, ctx:RADENNXParser.AtomContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#list_expr.
    def visitList_expr(self, ctx:RADENNXParser.List_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#mat_expr.
    def visitMat_expr(self, ctx:RADENNXParser.Mat_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#mat_row.
    def visitMat_row(self, ctx:RADENNXParser.Mat_rowContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#dataset_expr.
    def visitDataset_expr(self, ctx:RADENNXParser.Dataset_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#optimizer_expr.
    def visitOptimizer_expr(self, ctx:RADENNXParser.Optimizer_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#input_layer_expr.
    def visitInput_layer_expr(self, ctx:RADENNXParser.Input_layer_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#hidden_layer_expr.
    def visitHidden_layer_expr(self, ctx:RADENNXParser.Hidden_layer_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#output_layer_expr.
    def visitOutput_layer_expr(self, ctx:RADENNXParser.Output_layer_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#network_expr.
    def visitNetwork_expr(self, ctx:RADENNXParser.Network_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#if_expr.
    def visitIf_expr(self, ctx:RADENNXParser.If_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#elif_expr.
    def visitElif_expr(self, ctx:RADENNXParser.Elif_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#else_expr.
    def visitElse_expr(self, ctx:RADENNXParser.Else_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#for_expr.
    def visitFor_expr(self, ctx:RADENNXParser.For_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#while_expr.
    def visitWhile_expr(self, ctx:RADENNXParser.While_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#do_while_expr.
    def visitDo_while_expr(self, ctx:RADENNXParser.Do_while_exprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by RADENNXParser#func_def.
    def visitFunc_def(self, ctx:RADENNXParser.Func_defContext):
        return self.visitChildren(ctx)



del RADENNXParser