# Generated from D:/5th_Semester_Concepts/Compiler_Design/Project/RADENNX/grammar/RADENNX.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .RADENNXParser import RADENNXParser
else:
    from RADENNXParser import RADENNXParser

# This class defines a complete listener for a parse tree produced by RADENNXParser.
class RADENNXListener(ParseTreeListener):

    # Enter a parse tree produced by RADENNXParser#program.
    def enterProgram(self, ctx:RADENNXParser.ProgramContext):
        pass

    # Exit a parse tree produced by RADENNXParser#program.
    def exitProgram(self, ctx:RADENNXParser.ProgramContext):
        pass


    # Enter a parse tree produced by RADENNXParser#statements.
    def enterStatements(self, ctx:RADENNXParser.StatementsContext):
        pass

    # Exit a parse tree produced by RADENNXParser#statements.
    def exitStatements(self, ctx:RADENNXParser.StatementsContext):
        pass


    # Enter a parse tree produced by RADENNXParser#statement.
    def enterStatement(self, ctx:RADENNXParser.StatementContext):
        pass

    # Exit a parse tree produced by RADENNXParser#statement.
    def exitStatement(self, ctx:RADENNXParser.StatementContext):
        pass


    # Enter a parse tree produced by RADENNXParser#expr.
    def enterExpr(self, ctx:RADENNXParser.ExprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#expr.
    def exitExpr(self, ctx:RADENNXParser.ExprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#comp_expr.
    def enterComp_expr(self, ctx:RADENNXParser.Comp_exprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#comp_expr.
    def exitComp_expr(self, ctx:RADENNXParser.Comp_exprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#arith_expr.
    def enterArith_expr(self, ctx:RADENNXParser.Arith_exprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#arith_expr.
    def exitArith_expr(self, ctx:RADENNXParser.Arith_exprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#term.
    def enterTerm(self, ctx:RADENNXParser.TermContext):
        pass

    # Exit a parse tree produced by RADENNXParser#term.
    def exitTerm(self, ctx:RADENNXParser.TermContext):
        pass


    # Enter a parse tree produced by RADENNXParser#factor.
    def enterFactor(self, ctx:RADENNXParser.FactorContext):
        pass

    # Exit a parse tree produced by RADENNXParser#factor.
    def exitFactor(self, ctx:RADENNXParser.FactorContext):
        pass


    # Enter a parse tree produced by RADENNXParser#power.
    def enterPower(self, ctx:RADENNXParser.PowerContext):
        pass

    # Exit a parse tree produced by RADENNXParser#power.
    def exitPower(self, ctx:RADENNXParser.PowerContext):
        pass


    # Enter a parse tree produced by RADENNXParser#call.
    def enterCall(self, ctx:RADENNXParser.CallContext):
        pass

    # Exit a parse tree produced by RADENNXParser#call.
    def exitCall(self, ctx:RADENNXParser.CallContext):
        pass


    # Enter a parse tree produced by RADENNXParser#atom.
    def enterAtom(self, ctx:RADENNXParser.AtomContext):
        pass

    # Exit a parse tree produced by RADENNXParser#atom.
    def exitAtom(self, ctx:RADENNXParser.AtomContext):
        pass


    # Enter a parse tree produced by RADENNXParser#list_expr.
    def enterList_expr(self, ctx:RADENNXParser.List_exprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#list_expr.
    def exitList_expr(self, ctx:RADENNXParser.List_exprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#mat_expr.
    def enterMat_expr(self, ctx:RADENNXParser.Mat_exprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#mat_expr.
    def exitMat_expr(self, ctx:RADENNXParser.Mat_exprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#mat_row.
    def enterMat_row(self, ctx:RADENNXParser.Mat_rowContext):
        pass

    # Exit a parse tree produced by RADENNXParser#mat_row.
    def exitMat_row(self, ctx:RADENNXParser.Mat_rowContext):
        pass


    # Enter a parse tree produced by RADENNXParser#dataset_expr.
    def enterDataset_expr(self, ctx:RADENNXParser.Dataset_exprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#dataset_expr.
    def exitDataset_expr(self, ctx:RADENNXParser.Dataset_exprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#optimizer_expr.
    def enterOptimizer_expr(self, ctx:RADENNXParser.Optimizer_exprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#optimizer_expr.
    def exitOptimizer_expr(self, ctx:RADENNXParser.Optimizer_exprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#input_layer_expr.
    def enterInput_layer_expr(self, ctx:RADENNXParser.Input_layer_exprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#input_layer_expr.
    def exitInput_layer_expr(self, ctx:RADENNXParser.Input_layer_exprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#hidden_layer_expr.
    def enterHidden_layer_expr(self, ctx:RADENNXParser.Hidden_layer_exprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#hidden_layer_expr.
    def exitHidden_layer_expr(self, ctx:RADENNXParser.Hidden_layer_exprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#output_layer_expr.
    def enterOutput_layer_expr(self, ctx:RADENNXParser.Output_layer_exprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#output_layer_expr.
    def exitOutput_layer_expr(self, ctx:RADENNXParser.Output_layer_exprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#network_expr.
    def enterNetwork_expr(self, ctx:RADENNXParser.Network_exprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#network_expr.
    def exitNetwork_expr(self, ctx:RADENNXParser.Network_exprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#if_expr.
    def enterIf_expr(self, ctx:RADENNXParser.If_exprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#if_expr.
    def exitIf_expr(self, ctx:RADENNXParser.If_exprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#elif_expr.
    def enterElif_expr(self, ctx:RADENNXParser.Elif_exprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#elif_expr.
    def exitElif_expr(self, ctx:RADENNXParser.Elif_exprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#else_expr.
    def enterElse_expr(self, ctx:RADENNXParser.Else_exprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#else_expr.
    def exitElse_expr(self, ctx:RADENNXParser.Else_exprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#for_expr.
    def enterFor_expr(self, ctx:RADENNXParser.For_exprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#for_expr.
    def exitFor_expr(self, ctx:RADENNXParser.For_exprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#while_expr.
    def enterWhile_expr(self, ctx:RADENNXParser.While_exprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#while_expr.
    def exitWhile_expr(self, ctx:RADENNXParser.While_exprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#do_while_expr.
    def enterDo_while_expr(self, ctx:RADENNXParser.Do_while_exprContext):
        pass

    # Exit a parse tree produced by RADENNXParser#do_while_expr.
    def exitDo_while_expr(self, ctx:RADENNXParser.Do_while_exprContext):
        pass


    # Enter a parse tree produced by RADENNXParser#func_def.
    def enterFunc_def(self, ctx:RADENNXParser.Func_defContext):
        pass

    # Exit a parse tree produced by RADENNXParser#func_def.
    def exitFunc_def(self, ctx:RADENNXParser.Func_defContext):
        pass



del RADENNXParser