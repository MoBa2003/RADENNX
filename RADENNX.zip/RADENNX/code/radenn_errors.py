class Error:
    def __init__(self,error_name, details):
        self.error_name = error_name
        self.details = details

    def __str__(self):
        result = f"{self.error_name}: {self.details}\n"
        return result


class IllegalCharError(Error):
    def __init__(self, details):
        super().__init__("Illegal Character", details)


class ExpectedCharError(Error):
    def __init__(self, details):
        super().__init__("Expected Character", details)


class InvalidSyntaxError(Error):
    def __init__(self, details=""):
        super().__init__("Invalid Syntax", details)


class RTError(Error):
    def __init__(self, details, context):
        super().__init__("Runtime Error", details)
        self.context = context

    def __str__(self):
        result = self.generate_traceback()
        result += f"{self.error_name}: {self.details}"
        return result

    def generate_traceback(self):
        result = ""
        ctx = self.context
        while ctx:
            result = f"{ctx.display_name}\n" + result
            ctx = ctx.parent

        return "Traceback (most recent call last):\n" + result
