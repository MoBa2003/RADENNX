# from unittest.mock import right
from keras.src.backend.tensorflow.sparse import indexed_slices_union_indices_and_values
from tensorflow.python.autograph.operators.py_builtins import print_registry
from tensorflow.python.eager.monitoring import Counter

# from pygments.lexers.csound import newline
import  antlr4
from gen.RADENNXListener import RADENNXListener
from gen.RADENNXParser import RADENNXParser
from ast_maker.radenn_nodes import *
from ast_maker.parse_result import ParseResult



class CustomRADENNXListener(RADENNXListener):
    def __init__(self):
        self.ast = None

    def exitProgram(self, ctx:RADENNXParser.ProgramContext):
        ctx.parseresult = ctx.getChild(0).parseresult
        self.ast = ctx.parseresult.node



    def exitStatements(self, ctx: RADENNXParser.StatementsContext):
        ctx.parseresult = ParseResult()
        statments = []
        for child in ctx.getChildren():
            if isinstance(child, RADENNXParser.StatementContext):
               statment_node = ctx.parseresult.register(child.parseresult)
               statments.append(statment_node)
            else :
                ctx.parseresult.register_advancement()
        ctx.parseresult.success(ListNode(statments,ctx.start,ctx.stop))


    def exitStatement(self, ctx:RADENNXParser.StatementContext):
        ctx.parseresult = ParseResult()
        counter = 0
        if isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and  ctx.getChild(counter).getSymbol().type==RADENNXParser.RETURN:
            ctx.parseresult.register_advancement()
            counter+=1
            expr_node = None
            if counter<ctx.getChildCount():
               expr_node = ctx.parseresult.register(ctx.getChild(counter).parseresult)
            else:
                ...
            ctx.parseresult.success(ReturnNode(expr_node, ctx.start, ctx.stop))
            return  None

        elif  isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type==RADENNXParser.CONTINUE:
            ctx.parseresult.register_advancement()
            counter+=1
            ctx.parseresult.success(ContinueNode(ctx.start, ctx.stop))
            return  None

        elif  isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type==RADENNXParser.BREAK:
            ctx.parseresult.register_advancement()
            counter+=1
            ctx.parseresult.success(BreakNode(ctx.start,ctx.stop))
            return  None

        expr_node = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        ctx.parseresult.success(expr_node)

    def bin_op(self,ctx,counter, ops):
        counter = counter
        pos_start = ctx.getChild(counter).start
        left_parseresult = ctx.getChild(counter).parseresult
        res = ParseResult()
        left_node = res.register(left_parseresult)
        counter+=1

        while counter<ctx.getChildCount() and isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type in ops:
            op_tok = ctx.getChild(counter)
            res.register_advancement()
            counter+=1
            right_node = res.register(ctx.getChild(counter).parseresult)
            left_node = BinOpNode(left_node, op_tok, right_node,pos_start, ctx.getChild(counter).stop)
            counter+=1
        return res.success(left_node),counter

    def exitExpr(self, ctx:RADENNXParser.ExprContext):
        ctx.parseresult = ParseResult()
        counter = 0

        if isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type==RADENNXParser.VAR:
            ctx.parseresult.register_advancement()
            counter+=1

            var_name = ctx.getChild(counter)
            ctx.parseresult.register_advancement()
            counter+=1

            ctx.parseresult.register_advancement()

            counter+=1

            expr = ctx.parseresult.register(ctx.getChild(counter).parseresult)
            ctx.parseresult.success(VarAssignNode(var_name, expr, ctx.start, ctx.stop))
            return None

        parse_res,counter = self.bin_op(ctx, counter, [RADENNXParser.AND, RADENNXParser.OR])
        node = ctx.parseresult.register(parse_res)
        ctx.parseresult.success(node)

    def exitComp_expr(self, ctx:RADENNXParser.Comp_exprContext):
        ctx.parseresult = ParseResult()
        counter = 0

        if isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type ==RADENNXParser.NOT:
            op_tok = ctx.getChild(counter)
            ctx.parseresult.register_advancement()
            counter+=1
            node = ctx.parseresult.register(ctx.getChild(counter).parseresult)
            return ctx.parseresult.success(UnaryOpNode(op_tok, node, ctx.start, ctx.stop))

        parse_res,counter = self.bin_op(ctx,counter,[RADENNXParser.EE,RADENNXParser.NE,RADENNXParser.LT,RADENNXParser.GT,RADENNXParser.LTE,RADENNXParser.GTE])
        node = ctx.parseresult.register(parse_res)

        return ctx.parseresult.success(node)


    def exitArith_expr(self, ctx:RADENNXParser.Arith_exprContext):
        ctx.parseresult,counter =  self.bin_op(ctx,0,[RADENNXParser.PLUS,RADENNXParser.MINUS])

    def exitTerm(self, ctx:RADENNXParser.TermContext):
        ctx.parseresult,counter = self.bin_op(ctx,0, [RADENNXParser.MUL,RADENNXParser.DIV,RADENNXParser.MOD])

    def exitFactor(self, ctx:RADENNXParser.FactorContext):

        ctx.parseresult = ParseResult()
        counter = 0

        if isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type in [RADENNXParser.PLUS,RADENNXParser.MINUS]:
            ctx.parseresult.register_advancement()
            counter+=1
            factor = ctx.parseresult.register(ctx.getChild(counter).parseresult)
            return ctx.parseresult.success(UnaryOpNode(ctx.getChild(0), factor, ctx.start,ctx.stop))

        ctx.parseresult = ctx.getChild(0).parseresult


    def exitPower(self, ctx:RADENNXParser.PowerContext):
        ctx.parseresult,counter = self.bin_op(ctx,0, [RADENNXParser.POW])      # حواست باشه به اینجا چون رایت فانک رو ندادی


    def exitCall(self, ctx:RADENNXParser.CallContext):

        ctx.parseresult = ParseResult()
        counter = 0

        atom = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        if isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type==RADENNXParser.LPAREN:
            ctx.parseresult.register_advancement()
            counter+=1
            arg_nodes = []

            if isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type==RADENNXParser.RPAREN:
                ctx.parseresult.register_advancement()
                counter+=1
                return ctx.parseresult.success(CallNode(atom, arg_nodes, atom.pos_start, atom.pos_end))
            else:
                arg_nodes.append(ctx.parseresult.register(ctx.getChild(counter).parseresult))
                counter+=1
                while counter<ctx.getChildCount() and isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and  ctx.getChild(counter).getSymbol().type ==RADENNXParser.COMMA:
                    ctx.parseresult.register_advancement()
                    counter+=1
                    arg_nodes.append(ctx.parseresult.register(ctx.getChild(counter).parseresult))

                    counter+=1

                ctx.parseresult.register_advancement()
                counter+=1
                return ctx.parseresult.success(CallNode(atom, arg_nodes, ctx.start, ctx.stop))
        return ctx.parseresult.success(atom)

    def exitAtom(self, ctx:RADENNXParser.AtomContext):

        ctx.parseresult = ParseResult()
        try:

            first_token_type = ctx.getChild(0).getSymbol().type
        except:
            first_token_type = ctx.getChild(0).start.type

        if first_token_type in (RADENNXParser.INT, RADENNXParser.FLOAT):
            ctx.parseresult.register_advancement()
            numnode = NumberNode(ctx.getChild(0), ctx.start, ctx.stop)
            numnode.isint = True if first_token_type == RADENNXParser.INT else False
            ctx.parseresult.success(numnode)
            return None

        elif first_token_type == RADENNXParser.STRING:
            ctx.parseresult.register_advancement()
            ctx.parseresult.success(StringNode(ctx.getChild(0),ctx.start,ctx.stop))
            return None

        elif first_token_type == RADENNXParser.IDENTIFIER:
            ctx.parseresult.register_advancement()
            ctx.parseresult.success(VarAccessNode(ctx.getChild(0),ctx.start, ctx.stop))
            return None

        elif first_token_type == RADENNXParser.LPAREN:
            ctx.parseresult.register_advancement()
            expr_node = ctx.parseresult.register(ctx.getChild(1).parseresult)
            ctx.parseresult.success(expr_node)
            return None

        elif first_token_type ==RADENNXParser.LSQUARE:
            list_expr = ctx.parseresult.register(ctx.getChild(0).parseresult)
            ctx.parseresult.success(list_expr)
            return  None

        elif first_token_type == RADENNXParser.LROUND:

            mat_expr = ctx.parseresult.register(ctx.getChild(0).parseresult)
            ctx.parseresult.success(mat_expr)
            return  None

        elif first_token_type == RADENNXParser.DATASET :
            dataset_expr = ctx.parseresult.register(ctx.getChild(0).parseresult)
            ctx.parseresult.success(dataset_expr)
            return None

        elif first_token_type == RADENNXParser.OPTIMIZER:
            optimizer_expr = ctx.parseresult.register(ctx.getChild(0).parseresult)
            ctx.parseresult.success(optimizer_expr)
            return None

        elif first_token_type == RADENNXParser.INPUTLAYER:
            input_layer_expr = ctx.parseresult.register(ctx.getChild(0).parseresult)
            ctx.parseresult.success(input_layer_expr)
            return None

        elif first_token_type == RADENNXParser.HIDDENLAYER:
            hidden_layer_expr = ctx.parseresult.register(ctx.getChild(0).parseresult)
            ctx.parseresult.success(hidden_layer_expr)
            return  None

        elif first_token_type == RADENNXParser.OUTPUTLAYER:
            output_layer_expr = ctx.parseresult.register(ctx.getChild(0).parseresult)
            ctx.parseresult.success(output_layer_expr)
            return  None

        elif first_token_type == RADENNXParser.NETWORK:
            network_expr = ctx.parseresult.register(ctx.getChild(0).parseresult)
            ctx.parseresult.success(network_expr)
            return  None

        elif first_token_type == RADENNXParser.IF:
            if_expr = ctx.parseresult.register(ctx.getChild(0).parseresult)
            ctx.parseresult.success(if_expr)
            return  None

        elif first_token_type == RADENNXParser.FOR:
            for_expr = ctx.parseresult.register(ctx.getChild(0).parseresult)
            ctx.parseresult.success(for_expr)
            return  None

        elif first_token_type == RADENNXParser.WHILE:
            while_expr = ctx.parseresult.register(ctx.getChild(0).parseresult)
            ctx.parseresult.success(while_expr)
            return None

        elif first_token_type == RADENNXParser.DO:
            do_while_expr = ctx.parseresult.register(ctx.getChild(0).parseresult)
            ctx.parseresult.success(do_while_expr)
            return  None

        elif first_token_type == RADENNXParser.FUNCTION:
            func_def = ctx.parseresult.register(ctx.getChild(0).parseresult)
            ctx.parseresult.success(func_def)
            return None


    def exitList_expr(self, ctx:RADENNXParser.List_exprContext):

        ctx.parseresult = ParseResult()
        counter = 0
        elements = []
        pos_start = ctx.start

        ctx.parseresult.register_advancement()
        counter+=1

        if  isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type == RADENNXParser.RSQUARE:
            ctx.parseresult.register_advancement()
            counter+=1
        else:
            elements.append(ctx.parseresult.register(ctx.getChild(counter).parseresult))
            counter+=1
            while isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type == RADENNXParser.COMMA:
                ctx.parseresult.register_advancement()
                counter+=1
                elements.append(ctx.parseresult.register(ctx.getChild(counter).parseresult))
                counter+=1
            ctx.parseresult.register_advancement()
            counter+=1
        lst_node = ListNode(elements, pos_start,ctx.stop)
        lst_node.is_lst_expr=True
        ctx.parseresult.success(lst_node)
        return  None

    def exitMat_expr(self, ctx:RADENNXParser.Mat_exprContext):

        ctx.parseresult = ParseResult()
        counter = 0
        rows = []
        pos_start = ctx.start
        ctx.parseresult.register_advancement()
        counter+=1
        if  isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type == RADENNXParser.RROUND:
            ctx.parseresult.register_advancement()
            counter+=1
        else:
            row_node = ctx.parseresult.register(ctx.getChild(counter).parseresult)
            counter+=1
            rows.append(row_node)
            # columns = len(row_node)
            while counter<ctx.getChildCount() and isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type==RADENNXParser.COMMA:
                ctx.parseresult.register_advancement()
                counter+=1
                row_node = ctx.parseresult.register(ctx.getChild(counter).parseresult)
                counter+=1
                rows.append(row_node)

            ctx.parseresult.register_advancement()
            counter+=1
        ctx.parseresult.success(MatrixNode(rows, pos_start, ctx.stop))
        return None

    def exitMat_row(self, ctx:RADENNXParser.Mat_rowContext):

        ctx.parseresult = ParseResult()
        counter = 0
        elements = []


        ctx.parseresult.register_advancement()
        counter+=1

        elements.append(ctx.parseresult.register(ctx.getChild(counter).parseresult))
        counter+=1


        while counter<ctx.getChildCount() and isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type == RADENNXParser.COMMA:
            ctx.parseresult.register_advancement()
            counter+=1
            elements.append(ctx.parseresult.register(ctx.getChild(counter).parseresult))
            counter+=1


        ctx.parseresult.register_advancement()
        counter+=1
        ctx.parseresult.success(elements)
        return None


    def exitDataset_expr(self, ctx:RADENNXParser.Dataset_exprContext):

        ctx.parseresult = ParseResult()
        counter = 0
        pos_start = ctx.start

        ctx.parseresult.register_advancement()
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        data = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        labels = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        ctx.parseresult.success(DatasetNode(data, labels, pos_start, ctx.stop))
        return None


    def exitOptimizer_expr(self, ctx:RADENNXParser.Optimizer_exprContext):
        ctx.parseresult = ParseResult()
        counter = 0
        pos_start = ctx.start

        ctx.parseresult.register_advancement()
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        type_ = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        learning_rate = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        ctx.parseresult.success(OptimizerNode(type_, learning_rate, pos_start, ctx.stop))
        return None

    def exitInput_layer_expr(self, ctx:RADENNXParser.Input_layer_exprContext):

        ctx.parseresult = ParseResult()
        counter = 0
        pos_start = ctx.start

        ctx.parseresult.register_advancement()
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        input_neurons = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        hidden_neurons = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        kernel_initializer = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        batch_normalization = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        dropout_percentage = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        activation_function = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        ctx.parseresult.success(
            InputLayerNode(input_neurons, hidden_neurons, kernel_initializer, batch_normalization, dropout_percentage,
                           activation_function, pos_start,ctx.stop))
        return None


    def exitHidden_layer_expr(self, ctx:RADENNXParser.Hidden_layer_exprContext):

        ctx.parseresult = ParseResult()
        counter = 0
        pos_start = ctx.start

        ctx.parseresult.register_advancement()
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        neurons = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        kernel_initializer = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        batch_normalization = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        dropout_percentage = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        activation_function = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        ctx.parseresult.success(
            HiddenLayerNode(neurons, kernel_initializer, batch_normalization, dropout_percentage, activation_function,
                            pos_start, ctx.stop))
        return None

    def exitOutput_layer_expr(self, ctx:RADENNXParser.Output_layer_exprContext):

        ctx.parseresult = ParseResult()


        ctx.parseresult.register_advancement()


        ctx.parseresult.register_advancement()


        neurons_node = ctx.parseresult.register(ctx.getChild(2).parseresult)

        ctx.parseresult.register_advancement()


        kernel_initializer_node = ctx.parseresult.register(ctx.getChild(4).parseresult)

        ctx.parseresult.register_advancement()


        activation_function_node = ctx.parseresult.register(ctx.getChild(6).parseresult)



        ctx.parseresult.register_advancement()

        ctx.parseresult.success(
            OutputLayerNode(neurons_node, kernel_initializer_node, activation_function_node, ctx.start, ctx.stop))

        ctx.parseresult = ParseResult()
        counter = 0
        pos_start = ctx.start


        ctx.parseresult.register_advancement()
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        neurons = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        kernel_initializer = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        activation_function = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1
        ctx.parseresult.success(
            OutputLayerNode(neurons, kernel_initializer, activation_function, pos_start, ctx.stop))

    def exitNetwork_expr(self, ctx:RADENNXParser.Network_exprContext):

        ctx.parseresult = ParseResult()
        counter = 0
        pos_start =ctx.start


        ctx.parseresult.register_advancement()
        counter+=1

        ctx.parseresult.register_advancement()
        counter+=1

        input_layer = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        hidden_layers = []

        while counter<ctx.getChildCount() and isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type == RADENNXParser.COMMA:
            ctx.parseresult.register_advancement()
            counter+=1

            layer = ctx.parseresult.register(ctx.getChild(counter).parseresult)
            counter+=1

            hidden_layers.append(layer)

        output_layer = hidden_layers.pop(-1)

        ctx.parseresult.register_advancement()
        counter+=1

        return ctx.parseresult.success(NetworkNode(input_layer, hidden_layers, output_layer, pos_start,ctx.stop))


    def skip_newline(self,ctx,counter):

        while counter<ctx.getChildCount() and isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type == RADENNXParser.NEWLINE:
            ctx.parseresult.register_advancement()
            counter+=1
        return  counter





    def elif_or_else_expr(self,ctx,counter,case_keyword):

        res = ParseResult()
        cases, else_case = [], None

        if (isinstance(ctx.getChild(counter),RADENNXParser.Elif_exprContext)):

            all_cases = res.register(ctx.getChild(counter).parseresult)
            counter+=1
            cases, else_case = all_cases
        else:


            else_case = res.register(ctx.getChild(counter).parseresult)
            counter+=1

        return res.success([cases, else_case]),counter

    def if_expr_cases(self,ctx,counter, case_keyword):

        res = ParseResult()
        cases = []
        else_case = None
        counter = counter

        res.register_advancement()
        counter+=1

        condition = res.register(ctx.getChild(counter).parseresult)
        counter+=1

        counter = self.skip_newline(ctx,counter)

        if isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type == RADENNXParser.LROUND:
            res.register_advancement()
            counter+=1
            counter = self.skip_newline(ctx, counter)
            statemets = res.register(ctx.getChild(counter).parseresult)
            counter+=1


            cases.append([condition, statemets])
            counter = self.skip_newline(ctx, counter)

            res.register_advancement()  # skip the rround
            counter+=1

            counter =self.skip_newline(ctx,counter)
            if counter<ctx.getChildCount() and (isinstance(ctx.getChild(counter),RADENNXParser.Elif_exprContext) or isinstance(ctx.getChild(counter),RADENNXParser.Else_exprContext)) :
                context_key = RADENNXParser.ELIF if isinstance(ctx.getChild(counter),RADENNXParser.Elif_exprContext) else RADENNXParser.ELSE
                parse_res,counter = self.elif_or_else_expr(ctx, counter, context_key)

                all_cases = res.register(parse_res)
                # counter+=1
                new_cases, else_case = all_cases
                cases.extend(new_cases)

        else:

            # print(ctx.getChild(counter).getText())
            expr = res.register(ctx.getChild(counter).parseresult)
            counter+=1

            cases.append([condition, expr])

            counter = self.skip_newline(ctx,counter)
            if counter<ctx.getChildCount():

                   parse_res,counter = self.elif_or_else_expr(ctx, counter, None)
                   all_cases = res.register(parse_res)
                   # counter+=1
                   new_cases, else_case = all_cases
                   cases.extend(new_cases)
        return res.success([cases, else_case]),counter

    def exitIf_expr(self, ctx:RADENNXParser.If_exprContext):
        ctx.parseresult = ParseResult()
        pos_start = ctx.start
        parse_res,counter = self.if_expr_cases(ctx, 0, RADENNXParser.IF)
        all_cases = ctx.parseresult.register(parse_res)

        cases, else_case = all_cases
        return ctx.parseresult.success(IfNode(cases, else_case, pos_start, ctx.stop))

    def exitElif_expr(self, ctx:RADENNXParser.Elif_exprContext):
        ctx.parseresult = ParseResult()
        parse_res,counter =  self.if_expr_cases(ctx,0,RADENNXParser.ELIF)
        ctx.parseresult = parse_res

    def exitElse_expr(self, ctx:RADENNXParser.Else_exprContext):

        ctx.parseresult = ParseResult()
        counter = 0
        else_case = None

        if ctx.getChild(counter).getSymbol().type == RADENNXParser.ELSE:
            ctx.parseresult.register_advancement()
            counter+=1

            counter=  self.skip_newline(ctx,counter)

            if isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and  ctx.getChild(counter).getSymbol().type == RADENNXParser.LROUND:
                ctx.parseresult.register_advancement()
                counter+=1
                counter = self.skip_newline(ctx, counter)
                statements = ctx.parseresult.register(ctx.getChild(counter).parseresult)
                counter+=1

                else_case = statements


                ctx.parseresult.register_advancement()
                counter+=1


            else:
                expr = ctx.parseresult.register(ctx.getChild(counter).parseresult)
                counter+=1
                else_case = expr

        ctx.parseresult.success(else_case)
        return None





    def exitFor_expr(self, ctx:RADENNXParser.For_exprContext):

        ctx.parseresult = ParseResult()
        pos_start = ctx.start
        counter = 0

        ctx.parseresult.register_advancement()
        counter +=1


        ctx.parseresult.register_advancement()
        counter+=1


        var_name = ctx.getChild(counter)
        ctx.parseresult.register_advancement()
        counter+=1


        ctx.parseresult.register_advancement()
        counter+=1

        start_value = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1


        ctx.parseresult.register_advancement()
        counter+=1

        end_value = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1


        if counter<ctx.getChildCount() and isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type == RADENNXParser.COMMA :
            ctx.parseresult.register_advancement()
            counter+=1
            step_value = ctx.parseresult.register(ctx.getChild(counter).parseresult)
            counter+=1

        else:
            step_value = None


        ctx.parseresult.register_advancement()
        counter+=1

        counter = self.skip_newline(ctx, counter)

        if isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type == RADENNXParser.LROUND:
            ctx.parseresult.register_advancement()
            counter+=1
            body = ctx.parseresult.register(ctx.getChild(counter).parseresult)


            ctx.parseresult.register_advancement()
            counter+=1

            return ctx.parseresult.success(
                ForNode(var_name, start_value, end_value, step_value, body, pos_start, ctx.stop))

        body = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        return ctx.parseresult.success(
            ForNode(var_name, start_value, end_value, step_value, body, pos_start, ctx.stop))


    def exitWhile_expr(self, ctx:RADENNXParser.While_exprContext):
        ctx.parseresult = ParseResult()
        pos_start = ctx.start
        counter = 0


        ctx.parseresult.register_advancement()
        counter+=1

        condition = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        counter = self.skip_newline(ctx, counter)

        if isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type == RADENNXParser.LROUND:
            ctx.parseresult.register_advancement()
            counter+=1

            body = ctx.parseresult.register(ctx.getChild(counter).parseresult)
            counter+=1

            ctx.parseresult.register_advancement()
            counter+=1

            return ctx.parseresult.success(WhileNode(condition, body, pos_start, ctx.stop))

        body = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        ctx.parseresult.success(WhileNode(condition, body, pos_start, ctx.stop))
        return None

    def exitDo_while_expr(self, ctx:RADENNXParser.Do_while_exprContext):

        ctx.parseresult = ParseResult()
        pos_start = ctx.start
        counter = 0


        ctx.parseresult.register_advancement()
        counter+=1

        counter = self.skip_newline(ctx, counter)

        if isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type == RADENNXParser.LROUND:
            ctx.parseresult.register_advancement()
            counter+=1

            body = ctx.parseresult.register(ctx.getChild(counter).parseresult)
            counter+=1

            ctx.parseresult.register_advancement()
            counter+=1

        else:
            body = ctx.parseresult.register(ctx.getChild(counter).parseresult)
            counter+=1

            counter = self.skip_newline(ctx,counter)


        ctx.parseresult.register_advancement()
        counter+=1

        condition = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        counter+=1

        return ctx.parseresult.success(DoWhileNode(body, condition, pos_start, ctx.stop))

    def exitFunc_def(self, ctx:RADENNXParser.Func_defContext):

        ctx.parseresult = ParseResult()
        pos_start = ctx.start
        counter = 0


        ctx.parseresult.register_advancement()
        counter+=1

        if isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type == RADENNXParser.IDENTIFIER:
            var_name_tok = ctx.getChild(counter)
            ctx.parseresult.register_advancement()
            counter+=1


        else:
            var_name_tok = None

        ctx.parseresult.register_advancement()
        counter+=1

        arg_name_toks = []
        if isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type == RADENNXParser.IDENTIFIER:
            arg_name_toks.append(ctx.getChild(counter))
            ctx.parseresult.register_advancement()
            counter+=1

            while counter<ctx.getChildCount() and isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type == RADENNXParser.COMMA:
                ctx.parseresult.register_advancement()
                counter+=1

                arg_name_toks.append(ctx.getChild(counter))
                ctx.parseresult.register_advancement()
                counter+=1


        else:
           ...
        ctx.parseresult.register_advancement()
        counter+=1

        counter = self.skip_newline(ctx,counter)

        if  isinstance(ctx.getChild(counter),antlr4.tree.Tree.TerminalNode) and ctx.getChild(counter).getSymbol().type == RADENNXParser.LROUND:
            ctx.parseresult.register_advancement()
            counter+=1

            body = ctx.parseresult.register(ctx.getChild(counter).parseresult)
            counter+=1

            ctx.parseresult.register_advancement()
            counter+=1

            return ctx.parseresult.success(
                FuncDefNode(var_name_tok, arg_name_toks, body, False, pos_start, ctx.stop))

        body = ctx.parseresult.register(ctx.getChild(counter).parseresult)
        return ctx.parseresult.success(FuncDefNode(var_name_tok, arg_name_toks, body, True, pos_start,ctx.stop))